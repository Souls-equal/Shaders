// Aurora — outils communs : bruit, lumière du jour, étalonnage, ciel, brume.

// ── Maths ──────────────────────────────────────────────────────────────────

// Standard formula for relative luminance (apparent brightness).
fn luminance(colour: vec3f) -> f32 {
    return dot(colour, vec3f(0.2126, 0.7152, 0.0722));
}

// Map vec3i to a value between 0 and 1 inclusive. Same point = same output.
fn hash31(point: vec3i) -> f32 {
    let scaled = vec3u(point) * vec3u(73856093u, 19349663u, 83492791u);
    var hash = scaled.x ^ scaled.y ^ scaled.z;
    hash = (hash ^ (hash >> 13u)) * 1274126177u;
    hash = hash ^ (hash >> 16u);
    return f32(hash) / 4294967295.0;
}

// Smooth value noise between 0 and 1.
fn valueNoise3(point: vec3f) -> f32 {
    let base = floor(point);
    let local = point - base;
    let blend = local * local * (3.0 - 2.0 * local);
    let cell = vec3i(base);

    let c000 = hash31(cell);
    let c100 = hash31(cell + vec3i(1, 0, 0));
    let c010 = hash31(cell + vec3i(0, 1, 0));
    let c110 = hash31(cell + vec3i(1, 1, 0));
    let c001 = hash31(cell + vec3i(0, 0, 1));
    let c101 = hash31(cell + vec3i(1, 0, 1));
    let c011 = hash31(cell + vec3i(0, 1, 1));
    let c111 = hash31(cell + vec3i(1, 1, 1));

    let x00 = mix(c000, c100, blend.x);
    let x10 = mix(c010, c110, blend.x);
    let x01 = mix(c001, c101, blend.x);
    let x11 = mix(c011, c111, blend.x);
    return mix(mix(x00, x10, blend.y), mix(x01, x11, blend.y), blend.z);
}

// ── Lumière du jour ────────────────────────────────────────────────────────

struct SunInfo {
    direction: vec3f, // Vers le soleil de jour, vers la lune de nuit.
    strength: f32,    // 1 en plein jour, MOON_STRENGTH la nuit.
    day: f32,         // 0 = nuit, 1 = jour.
    golden: f32,      // 1 = soleil bas (aube, crépuscule).
    night: f32,       // 1 = pleine nuit.
    colour: vec3f,    // Couleur de la lumière directe.
    morning: f32,     // Pendant l'aube : 1 = matin (soleil côté est), 0 = soir.
}

fn sunInfo() -> SunInfo {
    let sun = bloxdSunDirection();
    let present = dot(sun, sun) > 0.0001;
    let flag = select(0.0, 1.0, present);
    let height = select(1.0, sun.y, present);

    let day = smoothstep(-0.12, 0.12, height);
    let golden = (1.0 - smoothstep(0.05, 0.4, height))
        * smoothstep(-0.2, 0.05, height) * flag;
    let night = (1.0 - smoothstep(-0.25, 0.02, height)) * flag;

    // Orange près de l'horizon, blanc chaud en altitude, bleu pour la lune.
    var colour = mix(vec3f(1.0, 0.45, 0.18), vec3f(1.0, 0.96, 0.88),
        smoothstep(0.0, 0.5, height));
    colour = mix(vec3f(0.45, 0.58, 0.95), colour, day);

    let towards = select(-sun, sun, height > 0.0);
    let direction = select(FALLBACK_LIGHT, towards, present);
    let strength = select(1.0, mix(MOON_STRENGTH, 1.0, day), present);
    let morning = smoothstep(-0.2, 0.2, dot(sun, SUN_EAST));
    return SunInfo(direction, strength, day, golden, night, colour, morning);
}

// ── Étalonnage ─────────────────────────────────────────────────────────────

// ACES filmic curve (Narkowicz), normalised so WHITE_POINT maps to 1.
fn acesFilm(x: vec3f) -> vec3f {
    let a = 2.51;
    let b = 0.03;
    let c = 2.43;
    let d = 0.59;
    let e = 0.14;
    return (x * (a * x + b)) / (x * (c * x + d) + e);
}

fn gradeColour(colour: vec3f, blockLightLuminance: f32, sun: SunInfo) -> vec3f {
    var c = max(colour, vec3f(0.0));

    // Ombres froides, lumières chaudes. Multiplicatif : le noir reste noir.
    c *= mix(SHADOW_TINT, LIGHT_TINT, smoothstep(0.08, 0.85, luminance(c)));

    // Soleil bas : tout se réchauffe.
    c *= mix(vec3f(1.0), mix(GOLDEN_TINT, MORNING_TINT, sun.morning), sun.golden * GOLDEN_AMOUNT);

    // Nuit bleutée et un peu désaturée, sauf là où une torche éclaire.
    let dark = 1.0 - saturate(blockLightLuminance * 1.6);
    c = mix(c, c * NIGHT_TINT, sun.night * NIGHT_AMOUNT * dark);
    c = mix(c, vec3f(luminance(c)), sun.night * NIGHT_DESATURATE * dark);

    // Courbe filmique : les hautes lumières (lave, néons) s'adoucissent.
    let white = acesFilm(vec3f(WHITE_POINT * EXPOSURE));
    let mapped = acesFilm(c * EXPOSURE) / white;
    c = mix(c, mapped, TONEMAP_MIX);
    c = saturate(c);

    // Contraste en S, puis saturation.
    c = mix(c, smoothstep(vec3f(0.0), vec3f(1.0), c), CONTRAST);
    c = mix(vec3f(luminance(c)), c, SATURATION);
    return saturate(c);
}

// ── Ciel et brume ──────────────────────────────────────────────────────────

// Part du ciel couverte de nuages (0 à 1) à une position du monde. Sert aux
// ombres de nuages au sol ET aux nuages reflétés dans l'eau : les deux
// coïncident, et défilent ensemble.
fn cloudCover(point: vec2f) -> f32 {
    let t = bloxdSeconds();
    let drift = point * CLOUD_SCALE + vec2f(t, t * 0.4) * (CLOUD_SPEED * CLOUD_SCALE);
    let big = valueNoise3(vec3f(drift, t * 0.01));
    let small = valueNoise3(vec3f(drift * 3.1 + 9.0, t * 0.02));
    return smoothstep(0.46, 0.72, big * 0.75 + small * 0.25);
}

// Colour of the sky seen in direction `dir`, with a glow around the sun and
// clouds on a flat layer high above the player.
fn skyGradient(dir: vec3f, sun: SunInfo) -> vec3f {
    let up = saturate(dir.y);
    var c = mix(SKY_HORIZON, SKY_ZENITH, pow(up, 0.5));

    // Nuages : on projette la direction sur un plan à CLOUD_HEIGHT blocs.
    let eye = bloxdWorldPosition(bloxdEyePosition());
    let onLayer = eye.xz + dir.xz / max(dir.y, 0.05) * CLOUD_HEIGHT;
    let cover = cloudCover(onLayer) * smoothstep(0.03, 0.22, dir.y) * CLOUD_REFLECTION;
    let cloudColour = mix(vec3f(0.68, 0.74, 0.85), vec3f(1.0), sun.day)
        * mix(vec3f(1.0), sun.colour, 0.35);
    c = mix(c, cloudColour, cover * 0.85);

    let towardsSun = saturate(dot(dir, sun.direction));
    let glow = pow(towardsSun, 96.0) * 0.8 + pow(towardsSun, 6.0) * 0.12;
    c += sun.colour * glow * sun.strength * (1.0 - cover * 0.7);
    return c;
}

// La lumière du ciel arrive du moteur sur une courbe en S qui relève les
// valeurs sombres (y = 1 - (1 - x/(3-2x))^3). On la restaure pour retrouver la
// vraie occlusion : sans ça, sous un arbre elle reste à 0.97 et l'ombre disparaît.
fn rawSkyLight(lifted: f32) -> f32 {
    let c = pow(max(1.0 - lifted, 0.0), 1.0 / 3.0);
    return 3.0 * (1.0 - c) / (3.0 - 2.0 * c);
}

// Fog colour for this fragment: the game's fog, lit up when facing the sun.
fn fogColourAt(light: BloxdLightIn, sun: SunInfo) -> vec3f {
    let toFragment = light.position - bloxdEyePosition();
    let view = toFragment / max(length(toFragment), 0.0001);
    let towardsSun = saturate(dot(view, sun.direction));
    let scatter = pow(towardsSun, FOG_SUN_POWER) * FOG_SUN_SCATTER
        * sun.strength * light.fogAlpha;
    return light.fogColour + sun.colour * scatter;
}

// Grade, then fog, in that order, like the engine does for lighting.
fn finishColour(colour: vec3f, emission: vec3f, light: BloxdLightIn, sun: SunInfo) -> vec3f {
    let graded = gradeColour(
        colour + emission, luminance(light.blockLight), sun);
    return mix(graded, fogColourAt(light, sun), light.fogAlpha);
}

// Packs can't construct BloxdLight, so copy the default one and set its colour.
fn withColour(surface: BloxdSurface, light: BloxdLightIn, colour: vec3f) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    out.colour = colour;
    return out;
}
