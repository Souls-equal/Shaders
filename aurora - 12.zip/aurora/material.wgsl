// Aurora — matériaux : relief, brillance, éclats, lueurs, végétation.

struct Material {
    spec: f32,    // Force du reflet du soleil.
    gloss: f32,   // Finesse du reflet (plus haut = plus petit).
    sparkle: f32, // Éclats scintillants.
    bump: f32,    // Relief des textures (0 = aucun).
}

// Items, vehicles, players and mobs aren't part of the world.
fn isWorldFace(flags: BloxdFlags) -> bool {
    return !(flags.held || flags.dropped || flags.thrown || flags.lifeform);
}

fn materialOf(id: u32, flags: BloxdFlags) -> Material {
    var material = Material(0.0, 16.0, 0.0, 1.0);
    if (isOre(id)) {
        material = Material(0.35, 40.0, 0.6, 1.0);
    } else if (isGemBlock(id)) {
        material = Material(0.9, 80.0, 0.6, 0.8);
    } else if (isMetalBlock(id)) {
        material = Material(0.6, 48.0, 0.2, 0.8);
    } else if (isIce(id)) {
        material = Material(0.7, 70.0, 0.4, 0.5);
    } else if (isSnow(id)) {
        material = Material(0.12, 24.0, 0.35, 0.7);
    } else if (isGlass(id)) {
        material = Material(0.9, 110.0, 0.0, 0.0);
    } else if (isSand(id)) {
        material = Material(0.04, 12.0, 0.0, 0.6);
    }

    // Plants, items and creatures keep their flat look; glowing blocks too,
    // except ores, which glow in spots and still have a rocky surface.
    if (flags.flat || !isWorldFace(flags)) {
        material.bump = 0.0;
    }
    if (flags.emissive && !isOre(id)) {
        material.bump = 0.0;
    }
    return material;
}

// ── Relief : une hauteur tirée de la luminosité de la texture ──────────────

// What the surface hook decided, for the light hook of the same fragment.
struct SurfaceState {
    normal: vec3f, // La normale, avec le relief de la texture.
    spec: f32,
    gloss: f32,
}
var<private> surfaceState: SurfaceState;

fn texelHeight(textureId: u32, uv: vec2f) -> f32 {
    let texel = bloxdTexel(textureId, uv, 0.0);
    return luminance(texel.rgb) * texel.a;
}

// The normal tilted by the texture's slope. It builds a tangent frame from
// screen-space derivatives, so it works for every face and texture rotation.
// Derivatives: call this outside any branch on a per-fragment value.
fn textureBump(surface: BloxdSurfaceIn) -> vec3f {
    let normal = surface.normal;
    let texel = 1.0 / vec2f(bloxdTextureSize(0.0));
    let left = texelHeight(surface.textureId, surface.uv - vec2f(texel.x, 0.0));
    let right = texelHeight(surface.textureId, surface.uv + vec2f(texel.x, 0.0));
    let down = texelHeight(surface.textureId, surface.uv - vec2f(0.0, texel.y));
    let up = texelHeight(surface.textureId, surface.uv + vec2f(0.0, texel.y));
    let slope = vec2f(right - left, up - down) * (0.5 * BUMP_STRENGTH);

    let dp1 = dpdx(surface.position);
    let dp2 = dpdy(surface.position);
    let duv1 = dpdx(surface.uv);
    let duv2 = dpdy(surface.uv);
    let dp2perp = cross(dp2, normal);
    let dp1perp = cross(normal, dp1);
    let tangent = dp2perp * duv1.x + dp1perp * duv2.x;
    let bitangent = dp2perp * duv1.y + dp1perp * duv2.y;
    let scale = inverseSqrt(max(max(dot(tangent, tangent), dot(bitangent, bitangent)), 1e-12));
    return normalize(normal - (tangent * slope.x + bitangent * slope.y) * scale);
}

// ── Éclats : quelques texels scintillent à tour de rôle ────────────────────

fn texelSparkle(surface: BloxdSurfaceIn, texelLuminance: f32, eyeDistance: f32) -> f32 {
    let size = vec2f(bloxdTextureSize(0.0));
    let texelCoord = vec2i(floor(fract(surface.uv) * size));
    let block = bloxdFragmentBlockPosition(surface.position, surface.normal);
    let seed = block.x * 7 + block.y * 13 + block.z * 29;

    let pick = hash31(vec3i(texelCoord.x, texelCoord.y, seed));
    let offset = hash31(vec3i(texelCoord.y + 5, texelCoord.x + 11, seed + 3));
    let phase = (bloxdSeconds() * 0.45 + offset * 8.0) % 1.0;
    let twinkle = pow(max(sin(phase * bloxdPi), 0.0), 18.0);

    let chosen = step(0.94, pick);                      // 6 % des texels.
    let bright = smoothstep(0.30, 0.65, texelLuminance); // Les clairs seulement.
    // Far away, texels are smaller than pixels and would shimmer.
    let fade = (1.0 - saturate(surface.mipLevel))
        * (1.0 - smoothstep(24.0, 56.0, eyeDistance));
    return twinkle * chosen * bright * fade;
}

// ── Lave ───────────────────────────────────────────────────────────────────

fn isLavaTexture(id: u32) -> bool {
    return id == bloxdTextureIdLava || isLavaLike(id);
}

fn lavaEmission(surface: BloxdSurfaceIn, texelLuminance: f32) -> vec3f {
    let world = bloxdWorldPosition(surface.position);
    let wave = (world.x * 0.7 + world.z * 0.9 + world.y * 0.5 + bloxdSeconds() * 1.3) % bloxdTau;
    let pulse = 0.5 + 0.5 * sin(wave);
    // The bright veins are hottest; the dark crust barely glows.
    let heat = 0.35 + smoothstep(0.25, 0.85, texelLuminance);
    return surface.colour * (LAVA_GLOW + LAVA_PULSE * pulse) * heat;
}

// ── Surface partagée par le terrain et les modèles ─────────────────────────

fn auroraSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    let flags = surface.flags;
    let id = surface.textureId;
    let eyeDistance = distance(bloxdEyePosition(), surface.position);
    let material = materialOf(id, flags);

    // Derivatives and texture reads come first, outside any branch.
    let bumped = textureBump(surface);
    let texel = bloxdTexel(id, surface.uv, 0.0);
    let texelLuminance = luminance(texel.rgb);

    // Bump fades with distance and mip level, so it never shimmers.
    let detail = (1.0 - saturate(surface.mipLevel))
        * (1.0 - smoothstep(BUMP_FADE_START, BUMP_FADE_END, eyeDistance));
    surfaceState.normal = normalize(mix(surface.normal, bumped, detail * material.bump));
    surfaceState.spec = material.spec;
    surfaceState.gloss = material.gloss;

    // Chaque bloc de feuilles ou d'herbe a sa propre teinte.
    let world = isWorldFace(flags);
    let block = bloxdFragmentBlockPosition(surface.position, surface.normal);
    let h1 = hash31(block) - 0.5;
    let h2 = hash31(block + vec3i(41, 17, 93)) - 0.5;
    let leaf = flags.vegetation && !flags.dirt;
    let grass = flags.vegetation && flags.dirt;
    let variation = select(0.0, LEAF_VARIATION, leaf) + select(0.0, GRASS_VARIATION, grass);
    let value = h1 * 2.0 * variation * select(0.0, 1.0, world);
    let warmth = h2 * 2.0 * variation * select(0.0, 1.0, world);
    out.colour *= vec3f(1.0 + value + warmth * 0.6, 1.0 + value, 1.0 + value - warmth);

    // Feuilles vivantes : la texture ondule et des vagues de lumière passent
    // dessus. Ça marche même dans les jeux stricts, où les sommets ne bougent pas.
    let worldPos = bloxdWorldPosition(surface.position);
    let gustPhase = (dot(worldPos.xz, vec2f(0.8, 0.6)) * 1.3 + bloxdSeconds() * 2.2) % bloxdTau;
    let wobble = vec2f(sin(gustPhase), cos(gustPhase * 0.8 + 1.0)) * LEAF_WOBBLE;
    let shifted = bloxdTexel(id, surface.uv + wobble, 0.0);
    let ratio = clamp((luminance(shifted.rgb) + 0.12) / (texelLuminance + 0.12), 0.7, 1.4);
    let shimmer = select(0.0, 1.0, leaf && world) * LEAF_SHIMMER;
    out.colour *= mix(1.0, ratio, shimmer) * (1.0 + sin(gustPhase) * 0.1 * shimmer);

    // Variation de luminosité des blocs (hors végétation, déjà traitée plus
    // haut) : un écart par bloc, plus de petites taches pixelisées dessus,
    // pour casser l'aspect uniforme des grandes surfaces.
    let cellPos = floor(worldPos * 8.0 - surface.normal * 0.5);
    let spots = valueNoise3(cellPos * (1.3 / 8.0)) - 0.5;
    let blockVariable = select(0.0, 1.0, world && !flags.emissive && !flags.vegetation);
    out.colour *= 1.0 + (h1 * 2.0 * BLOCK_VARIATION + spots * 2.0 * BLOCK_PATCH) * blockVariable;

    // Lueurs, ajoutées après l'éclairage.
    var emission = vec3f(0.0);
    let glowing = smoothstep(0.30, 0.75, texelLuminance);
    if (isLavaTexture(id)) {
        emission += lavaEmission(surface, texelLuminance);
    } else if (flags.emissive) {
        emission += surface.colour * glowing * EMISSIVE_BOOST;
    }
    if (isNeon(id) || isLamp(id)) {
        emission += surface.colour * NEON_GLOW;
    }
    if (isPortal(id)) {
        let shimmer = 0.75 + 0.25 * sin((bloxdSeconds() * 2.0 + texelLuminance * 6.0) % bloxdTau);
        emission += surface.colour * PORTAL_GLOW * shimmer;
    }

    // Éclats sur les minerais, la neige, la glace, les gemmes.
    let sparkle = texelSparkle(surface, texelLuminance, eyeDistance);
    emission += mix(surface.colour, vec3f(1.0), 0.6) * sparkle * material.sparkle * SPARKLE_STRENGTH;

    // Les objets enchantés brillent.
    if (surface.enchantTier > 0u) {
        let tier = 1.0 + 0.2 * f32(surface.enchantTier);
        emission += surface.enchantColour.rgb * surface.enchantColour.a * ENCHANT_GLOW * tier;
    }

    out.emission = emission;
    return out;
}

// ── Lumière partagée par le terrain et les modèles ─────────────────────────

fn auroraLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    let sun = sunInfo();
    let flags = light.flags;
    let normal = light.normal;
    let bumped = surfaceState.normal;
    let toFragment = light.position - bloxdEyePosition();
    let view = toFragment / max(length(toFragment), 0.0001);

    // Le soleil n'éclaire que ce qui voit le ciel.
    let exposure = smoothstep(0.35, 0.9, light.skyLight) * sun.strength;
    var colour = light.litColour;

    // Relief : les pentes face au soleil s'éclairent, les creux s'assombrissent.
    let sunBump = (dot(bumped, sun.direction) - dot(normal, sun.direction)) * BUMP_SUN * exposure;
    let crevice = (1.0 - dot(bumped, normal)) * BUMP_CREVICE;
    colour *= max(1.0 + sunBump - crevice, 0.0);

    // Côtés des blocs : chauds face au soleil, froids du côté de l'ombre.
    let wrap = saturate(dot(normal, sun.direction) * 0.5 + 0.5);
    colour *= mix(vec3f(1.0),
        mix(SIDE_SHADE_TINT, SIDE_LIT_TINT, wrap),
        SIDE_TINT_STRENGTH * sun.day * exposure);

    // Nuit : le moteur ne baisse pas la lumière du terrain, c'est ici qu'on le
    // fait. Les torches et la lumière tenue gardent tout leur éclat.
    let localLight = max(max(light.blockLight.r, light.blockLight.g),
        max(max(light.blockLight.b, light.heldLight.r), max(light.heldLight.g, light.heldLight.b)));
    let protectLocal = smoothstep(0.03, 0.35, localLight);
    colour *= mix(1.0, NIGHT_DIM, sun.night * (1.0 - protectLocal));

    // Ombres approchées. La lumière du ciel baisse sous les feuillages et les
    // surplombs : c'est notre ombre portée. Les faces opposées au soleil
    // s'assombrissent, et des nuages projettent des taches sur le sol.
    let world = bloxdWorldPosition(light.position);
    let t = bloxdSeconds();
    // Voxel shadow map du moteur : la lumière du ciel brute dit si le point voit
    // le ciel. Le seuil règle jusqu'à quel rayon d'occlusion c'est de l'ombre.
    let raw = rawSkyLight(light.skyLight);
    let threshold = SHADOW_THRESHOLD + SHADOW_LONG * (1.0 - saturate(sun.direction.y));
    let open = smoothstep(threshold - SHADOW_SOFT, threshold + SHADOW_SOFT, raw);
    // Fully enclosed places are already dark; only shade partly sky-lit ones.
    let partly = smoothstep(0.1, 0.4, raw);
    let covered = (1.0 - open) * partly;

    // Sous un feuillage, la lumière passe par taches mouvantes (pixelisées).
    let spot = floor(world * 4.0) / 4.0;
    let leafLight = valueNoise3(vec3f(spot.xz * 0.9 + vec2f(t * 0.3, t * 0.2), spot.y * 0.9 + t * 0.15));
    let dappled = mix(1.0, 0.45 + 1.1 * smoothstep(0.30, 0.75, leafLight), SHADOW_DAPPLE);

    // Nuages : deux échelles, décalés selon la hauteur du soleil pour que
    // l'ombre glisse sur les reliefs au lieu de rester collée au sol.
    let slide = sun.direction.xz / max(sun.direction.y, 0.25) * world.y;
    let cloud = cloudCover(world.xz - slide);

    let sunSide = smoothstep(-0.25, 0.55, dot(normal, sun.direction));
    // Soleil bas : les ombres sont plus longues et plus profondes.
    let lowSun = 1.0 + sun.golden * SHADOW_GOLDEN_BOOST;
    let shadow = sun.day * saturate(
        SHADOW_OCCLUSION * covered * dappled * lowSun
        + SHADOW_FORM * (1.0 - sunSide) * open
        + SHADOW_CLOUD * cloud * open);
    // Les ombres bleuissent un peu plus quand le soleil est bas.
    let evening = sun.golden * (1.0 - sun.morning);
    let tint = mix(SHADOW_CAST_TINT, SHADOW_CAST_TINT * EVENING_SHADOW_TINT, evening);
    colour *= mix(vec3f(1.0), tint, shadow);

    // Lumière de lune (direction = opposé du soleil) sur ce qui voit le ciel.
    let moonDiffuse = saturate(dot(normal, sun.direction));
    colour += surface.colour * MOON_LIGHT_COLOUR * moonDiffuse * sun.night * NIGHT_MOON * open;

    // Reflet du soleil (Blinn-Phong) sur la normale en relief.
    let halfway = sun.direction - view;
    let halfwayDir = halfway / max(length(halfway), 0.0001);
    let facing = smoothstep(0.0, 0.25, dot(normal, sun.direction));
    let specular = pow(saturate(dot(bumped, halfwayDir)), surfaceState.gloss)
        * surfaceState.spec * SPEC_STRENGTH * facing * exposure;
    colour += sun.colour * specular;

    // Feuilles et plantes : la lumière les traverse à contre-jour.
    let leaf = flags.vegetation && !flags.dirt;
    let backlit = pow(saturate(dot(view, sun.direction)), 3.0);
    colour += light.litColour * vec3f(0.85, 1.0, 0.35) * backlit * exposure
        * LEAF_TRANSLUCENCY * select(0.0, 1.0, leaf);

    // Liseré de ciel sur les joueurs et les mobs.
    let rim = pow(1.0 - saturate(dot(normal, -view)), 3.0);
    colour += light.skyLightColour * light.skyLight * rim * RIM_STRENGTH
        * select(0.0, 1.0, flags.lifeform);

    // Les lueurs gagnent en force dans le noir.
    let darkness = 1.0 - sun.day * smoothstep(0.3, 0.9, light.skyLight);
    let emission = surface.emission * (1.0 + EMISSIVE_NIGHT_BOOST * darkness);

    return withColour(surface, light, finishColour(colour, emission, light, sun));
}
