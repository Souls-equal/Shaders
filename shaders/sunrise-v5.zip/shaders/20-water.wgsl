// ============================================================================
//  20-water.wgsl : eau (programme "liquid")
//  - vagues reelles (vertex, jeux "allow" uniquement)
//  - normales de vague procedurales + reflet de ciel + reflet du soleil
//  - absorption en profondeur via la texture de scene (bloxdOpaqueBehind)
// ============================================================================

// Normale de vague : somme de 3 sinusoides, derivees analytiques.
fn ghWaveNormal(p: vec3f, t: f32) -> vec3f {
    let s = ghWaveScale;
    let c1 = cos(p.x * 1.00 * s + t * 1.60 * ghWaveSpeed);
    let c2 = cos(p.z * 1.35 * s + t * 1.28 * ghWaveSpeed);
    let c3 = cos((p.x + p.z) * 0.70 * s - t * 1.76 * ghWaveSpeed);
    let dhdx = 0.50 * c1 + 0.15 * 0.70 * c3;
    let dhdz = 0.35 * 1.35 * c2 + 0.15 * 0.70 * c3;
    return normalize(vec3f(-dhdx * 0.55, 1.0, -dhdz * 0.55));
}

// --------------------------------------------------------- vagues (vertex) --
// Les jeux "strict" interdisent tout deplacement de sommet : tout est protege.
#ifndef BLOXD_STRICT
fn bloxdLiquidVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    let topness = clamp(vertex.normal.y * 2.0, 0.0, 1.0);
    if (topness > 0.001) {
        let wp = bloxdWorldPosition(vertex.position);
        let t = bloxdSeconds();
        let h = sin(wp.x * 0.9 * ghWaveScale + t * 1.6 * ghWaveSpeed)
              + sin(wp.z * 1.2 * ghWaveScale + t * 1.3 * ghWaveSpeed) * 0.7;
        out.position.y += h * 0.055 * topness;
    }
    return out;
}
#endif

// ---------------------------------------------------------------- surface --
fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    let worldPos = bloxdWorldPosition(surface.position);
    let t = bloxdSeconds();

    // Reflet du ciel : l'eau prend la teinte doree du ciel au lieu du bleu plat.
    out.colour = mix(out.colour, ghWaterSky, 0.22);

    // Scintillement lent de la surface (varie avec la position monde).
    let shimmer = sin(t * 1.3 + worldPos.x * 0.55 + worldPos.z * 0.35);
    out.colour *= 1.0 + shimmer * 0.05;

    // Transparence liee a l'epaisseur : plus c'est profond, plus c'est opaque.
    // (alpha n'existe que dans les variantes BLOXD_ALPHA)
#ifdef BLOXD_ALPHA
    let thickness = ghWaterThicknessAt(surface.position);
    let depth01 = clamp(thickness / 6.0, 0.0, 1.0);
    out.alpha = clamp(surface.alpha * mix(ghWaterAlphaShallow, 1.0, depth01), 0.0, 1.0);
#endif
    return out;
}

// ------------------------------------------------------------------ light --
fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    if (!bloxdLit()) { return out; }

    let sunDir = ghSunDirection();
    let baseN = normalize(light.normal);
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let worldPos = bloxdWorldPosition(light.position);
    let t = bloxdSeconds();

    // --- normales de vague sur les faces du dessus ------------------------
    let topness = clamp(baseN.y * 2.0, 0.0, 1.0);
    let waveN = normalize(mix(baseN, ghWaveNormal(worldPos, t), topness));

    // --- Fresnel : l'eau reflechit le ciel a angle rasant -----------------
    let facing = clamp(dot(waveN, viewDir), 0.0, 1.0);
    let fresnel = 0.02 + 0.98 * pow(1.0 - facing, 5.0);

    // --- absorption : plus c'est epais, plus c'est profond/bleu-vert --------
    let thickness = ghWaterThicknessAt(light.position);
    let absorb = 1.0 - exp(-thickness * ghWaterAbsorb);
    var colour = mix(out.colour * mix(vec3f(1.0), ghWaterSky, 0.35), ghWaterDeep, absorb * 0.6);

    // --- reflet du ciel (pseudo) -----------------------------------------
    let skyReflect = mix(ghWaterSky, ghHazeColour, 0.45) * (0.70 + 0.30 * light.skyLight);
    colour = mix(colour, skyReflect, fresnel * ghWaterSkyReflect);

    // --- reflet du soleil : le "chemin d'or" sur l'eau ---------------------
    if (ghSunStrength() > 0.5) {
        let halfDir = normalize(viewDir + sunDir);
        let ndh = clamp(dot(waveN, halfDir), 0.0, 1.0);
        let glint = pow(ndh, 220.0) * ghWaterGlint;
        let broad = pow(ndh, 24.0) * ghWaterGlint * 0.18;
        let sunlit = (1.0 - absorb * 0.5);
        colour += ghGlintTint * ((glint + broad) * sunlit * ghSunStrength());
    }

    // --- eau eclairee par une torche : reflet chaud ------------------------
    let torch = ghBlockLightAmount(light);
    if (torch > 0.001) {
        colour = mix(colour, colour * vec3f(1.18, 0.95, 0.70), 0.40 * torch);
    }

    // --- atmosphere + etalonnage (identiques au terrain) ------------------
    let dist = distance(bloxdEyePosition(), light.position);
    let haze = clamp(1.0 - exp(-dist * ghHazeDensity), 0.0, ghHazeMax);
    let hazeCol = mix(light.fogColour, ghHazeColour, 0.65);
    colour = mix(colour, hazeCol, max(haze, light.fogAlpha * 0.85));

    colour = ghGrade(colour);

    out.colour = colour;
    return out;
}
