// ============================================================================
//  10-terrain.wgsl : blocs (hors eau et modeles) + modeles de blocs
//  Surface = matiere (albedo, emission) ; Light = couleur finale a l'ecran.
// ============================================================================

// Une surface "traitee" partagee par les hooks surface de tous les programmes,
// avec un facteur d'attenuation pour n'appliquer qu'une partie des effets aux
// entites (joueurs/mobs) et aux objets tenus.
fn ghSurface(s: BloxdSurfaceIn, sparks: f32) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    let worldPos = bloxdWorldPosition(s.position);
    let t = bloxdSeconds();

    // 1. Etincelles sur les minerais : lecture de la texture (surface/light only)
    //    et comparaison au catalogue de constantes bloxdTextureId*.
    var sparkle = 0.0;
    if (s.textureId == bloxdTextureIdDiamondOre) {
        sparkle = ghSparkle(worldPos, 1.7, t);
    } else if (s.textureId == bloxdTextureIdGoldOre) {
        sparkle = ghSparkle(worldPos, 4.3, t);
    } else if (s.textureId == bloxdTextureIdEmeraldOre) {
        sparkle = ghSparkle(worldPos, 7.1, t);
    } else if (s.textureId == bloxdTextureIdLapisOre) {
        sparkle = ghSparkle(worldPos, 9.4, t) * 0.7;
    }

    // 2. Pulsation chaude des blocs lumineux (lave, glowstone, magma...)
    if (s.flags.emissive) {
        let lum = ghLuma(out.colour);
        let breath = 1.0 + ghEmissivePulse * sin(t * 1.6 + worldPos.x * 0.7 + worldPos.z * 0.9);
        out.emission += out.colour * lum * 0.85 * breath * ghEmissiveTint;
    }

    // 3. Matieres naturelles : on rechauffe tres legerement terre et sable,
    //    la roche reste neutre (elle prend sa couleur du hook light).
    if (s.flags.dirt) {
        out.colour *= vec3f(1.03, 1.01, 0.97);
    } else if (s.flags.sand) {
        out.colour *= vec3f(1.05, 1.01, 0.94);
    }

    // 4. Etincelles (additif, applique dans le hook light via l'emission)
    out.emission += ghSparkleTint * (sparkle * sparks * ghSparkleAmount);

    return out;
}

fn ghTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    // La lumiere du jeu est coupee : on ne touche a rien, resultat identique au jeu.
    if (!bloxdLit()) { return out; }

    let sunDir = ghSunDirection();
    let n = normalize(light.normal);
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let facing = clamp(dot(n, viewDir), 0.0, 1.0);

    // --- 1. Directionnel chaud, gated par l'orientation de la face ---------
    let ndl = clamp(dot(n, sunDir), 0.0, 1.0);
    let oriented = mix(1.0, ndl, ghSunGate);
    let sunlit = ghSunlit(light) * ghSunStrength();

    let warm = ghWarm * (0.55 + 0.45 * oriented);
    let cool = ghCool;
    let directWeight = clamp(sunlit * (0.45 + 0.55 * oriented), 0.0, 1.0);
    let tint = mix(cool, warm, directWeight);

    // --- 2. Ombres : assombrit les zones sans vue du ciel ------------------
    let shadowMask = 1.0 - sunlit;
    let shadowFade = 1.0 - ghShadowDarken * shadowMask * (0.35 + 0.65 * (1.0 - ghBlockLightAmount(light)));

    // On repart de la couleur eclairee SANS la brume du moteur
    // (bloxdLitColour = avant emission et avant fog) pour lui substituer
    // notre propre atmosphere, plutot que d'empiler deux brumes.
    var colour = bloxdLitColour(surface, light) * tint * shadowFade;

    // --- 3. Halo chaud autour des torches / lave --------------------------
    let torch = ghBlockLightAmount(light);
    if (torch > 0.001) {
        colour = mix(colour, colour * vec3f(1.10, 0.97, 0.80), 0.40 * torch);
    }

    // --- 4. Speculaire du soleil (Blinn-Phong) ----------------------------
    if (ghSunStrength() > 0.5) {
        let halfDir = normalize(viewDir + sunDir);
        let ndh = clamp(dot(n, halfDir), 0.0, 1.0);
        let spec = pow(ndh, ghGlintPower) * ghGlintStrength;
        let gate = smoothstep(0.0, 0.25, ndl) * sunlit;
        // L'eau a son propre reflet : on reserve le miroitement dur au terrain.
        if (light.flags.rock || light.flags.opaque || light.flags.sand) {
            colour += ghGlintTint * (spec * gate * 3.0);
        } else {
            colour += ghGlintTint * (spec * gate);
        }
    }

    // --- 5. Frange rasant a contre-jour (rim) -----------------------------
    let rim = pow(1.0 - facing, 3.0) * 0.10 * sunlit;
    colour += ghWarm * rim;

    // --- 6. Emission (deja brumee : on la reinjecte comme le moteur) ------
    colour += surface.emission * (1.0 - light.fogAlpha);

    // --- 7. Atmosphere doree qui remplace la brume ------------------------
    let dist = distance(bloxdEyePosition(), light.position);
    let haze = clamp(1.0 - exp(-dist * ghHazeDensity), 0.0, ghHazeMax);
    // Elle ne doit pas "laver" ce qui est proche de la camera.
    let hazeCol = mix(light.fogColour, ghHazeColour, 0.65);
    colour = mix(colour, hazeCol, max(haze, light.fogAlpha * 0.85));

    // --- 8. Etalonnage final ---------------------------------------------
    colour = ghGrade(colour);

    out.colour = colour;
    return out;
}

// ----------------------------------------------------------------- terrain --
fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return ghSurface(surface, 1.0);
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return ghTerrainLight(surface, light);
}

// ------------------------------------------------------------------- model --
// Joueurs, mobs, objets tenus/laches : memes couleurs, effets adoucis.
fn bloxdModelSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return ghSurface(surface, 0.35);
}

fn bloxdModelLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return ghTerrainLight(surface, light);
}
