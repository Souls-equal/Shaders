// ============================================================================
//  Golden Hour - Bloxd.io shader pack (API v5, WebGPU renderer)
//  00-common.wgsl : reglages + helpers partages
//  Tout identifiant commencant par "bloxd" est reserve par le moteur :
//  nos helpers utilisent donc le prefixe "gh".
//  L'en-tete du moteur (structs + fonctions bloxd*) est injecte avant ce code.
//  Ce fichier est du WGSL : les accents sont volontairement evites.
// ============================================================================

// ---------------------------------------------------------------- reglages --
// Un seul endroit a modifier pour changer l'ambiance du pack.

// Etalonnage global
const ghExposure: f32 = 1.02;           // exposition generale
const ghSaturation: f32 = 1.14;         // saturation de la couleur finale
const ghContrast: f32 = 1.06;           // micro-contraste (courbe en S douce)

// Soleil et ombres
const ghSunGate: f32 = 0.45;            // 0 = ignore l'orientation de la face, 1 = tres directionnel
const ghWarm: vec3f = vec3f(1.26, 1.02, 0.74);   // lumiere directe (chaude)
const ghCool: vec3f = vec3f(0.68, 0.82, 1.18);   // zones a l'ombre (froides)
const ghShadowThreshold: f32 = 0.82;    // rayon d'occlusion compte comme ombre (0.93=1.5bl, 0.80=3bl, 0.67=5bl)
const ghShadowSoftness: f32 = 0.10;     // douceur de la transition d'ombre
const ghShadowDarken: f32 = 0.40;       // assombrissement du centre des ombres (0 = aucune ombre)

// Miroitement du soleil sur les blocs
const ghGlintPower: f32 = 84.0;         // nettete du reflet (grand = petit point brillant)
const ghGlintStrength: f32 = 0.20;
const ghGlintTint: vec3f = vec3f(1.00, 0.94, 0.84);

// Blocs lumineux (lave, glowstone, magma) et minerais
const ghEmissivePulse: f32 = 0.10;      // pulsation lente des blocs lumineux
const ghEmissiveTint: vec3f = vec3f(1.00, 0.92, 0.80);
const ghSparkleTint: vec3f = vec3f(1.00, 0.88, 0.62);
const ghSparkleAmount: f32 = 0.55;      // intensite des etincelles de minerais

// Eau (programme liquid)
const ghWaterSky: vec3f = vec3f(0.34, 0.52, 0.82);   // couleur "ciel reflechi"
const ghWaterDeep: vec3f = vec3f(0.03, 0.22, 0.30);  // absorption en profondeur
const ghWaterAbsorb: f32 = 0.16;        // absorption par bloc d'epaisseur
const ghWaterSkyReflect: f32 = 0.45;    // part de ciel reflechie a angle rasant
const ghWaterAlphaShallow: f32 = 0.80;  // transparence minimale pres de la berge
const ghWaveScale: f32 = 1.0;           // frequence des vagues
const ghWaveSpeed: f32 = 1.35;          // vitesse des vagues
const ghWaterGlint: f32 = 1.15;         // intensite du chemin d'or du soleil

// Atmosphere (brume doree qui remplace la brume du jeu)
const ghHazeColour: vec3f = vec3f(0.86, 0.76, 0.58);
const ghHazeDensity: f32 = 0.0026;      // 0 = pas de brume ajoutee
const ghHazeMax: f32 = 0.62;            // opacite maximale de la brume lointaine

// Vegetation (hooks vertex, jeux "allow" uniquement)
const ghSwayAmount: f32 = 0.055;        // amplitude du vent en blocs
const ghSwaySpeed: f32 = 1.7;

// ---------------------------------------------------------------- helpers --

// Courbe de levage du skyLight du moteur (y = 1-(1-x/(3-2x))^3). On l'inverse
// pour retrouver la vraie valeur voxel : sans cela, les ombres restent
// quasiment invisibles (sous un arbre, l.skyLight vaut deja 0.97).
fn ghUnlift(y: f32) -> f32 {
    let c = pow(clamp(1.0 - y, 0.0, 1.0), 1.0 / 3.0);
    return clamp(3.0 * (1.0 - c) / max(3.0 - 2.0 * c, 1e-4), 0.0, 1.0);
}

fn ghLuma(c: vec3f) -> f32 {
    return dot(c, vec3f(0.2126, 0.7152, 0.0722));
}

// Saturation autour de la luminance (la luminosite globale est preservee).
fn ghSaturate(c: vec3f, amount: f32) -> vec3f {
    let l = ghLuma(c);
    return clamp(mix(vec3f(l), c, amount), vec3f(0.0), vec3f(1.0));
}

// Courbe filmique (ACES, approximation de Narkowicz) : garde les hautes
// lumieres dorees sans les bruler.
fn ghToneMap(x: vec3f) -> vec3f {
    let a = clamp(x, vec3f(0.0), vec3f(4.0));
    return clamp((a * (vec3f(2.51) * a + vec3f(0.03))) /
                 (a * (vec3f(2.43) * a + vec3f(0.59)) + vec3f(0.14)),
                 vec3f(0.0), vec3f(1.0));
}

// Etalonnage final, identique pour le terrain, l'eau et les modeles :
//   1. exposition
//   2. split-toning : hautes lumieres chaudes, ombres froides
//   3. courbe en S douce (contraste)
//   4. saturation
//   5. repli filmique uniquement dans les hautes lumieres
fn ghGrade(colour: vec3f) -> vec3f {
    var c = max(colour, vec3f(0.0)) * ghExposure;
    let l = ghLuma(c);

    c += ghWarm * 0.055 * smoothstep(0.35, 1.0, l);
    c += ghCool * 0.040 * (1.0 - smoothstep(0.0, 0.45, l));

    let sc = clamp(c, vec3f(0.0), vec3f(1.0));
    c = clamp(sc + (ghContrast - 1.0) * 3.0 * sc * (1.0 - sc) * (sc - 0.5), vec3f(0.0), vec3f(1.0));
    c = ghSaturate(c, ghSaturation);

    let hi = smoothstep(vec3f(0.72), vec3f(1.0), c);
    c = mix(c, ghToneMap(c * 1.12), hi);
    return clamp(c, vec3f(0.0), vec3f(1.0));
}

// Direction du soleil, normalisee, avec repli quand le ciel n'a pas de soleil.
fn ghSunDirection() -> vec3f {
    let d = bloxdSunDirection();
    if (dot(d, d) < 1e-6) { return vec3f(0.0); }
    return normalize(d);
}

// 0 = pas de soleil (ciel sans soleil), 1 = soleil present.
fn ghSunStrength() -> f32 {
    return select(0.0, 1.0, dot(bloxdSunDirection(), bloxdSunDirection()) > 1e-6);
}

// "Vue du ciel" 0..1 : ombre voxel binarisee, la base des ombres du pack.
fn ghSunlit(light: BloxdLightIn) -> f32 {
    let sunDir = ghSunDirection();
    // Soleil bas = ombres plus longues : on releve le seuil quand il descend.
    let lowSun = 1.0 - clamp(sunDir.y, 0.0, 1.0);
    let th = clamp(ghShadowThreshold + 0.10 * lowSun, 0.0, 0.995);
    let raw = ghUnlift(clamp(light.skyLight, 0.0, 1.0));
    let soft = max(ghShadowSoftness, 1e-3);
    return smoothstep(th - soft, th + soft, raw);
}

// Intensite de la lumiere de bloc (torche, lave) a ce fragment.
fn ghBlockLightAmount(light: BloxdLightIn) -> f32 {
    return clamp(max(light.blockLight.r, max(light.blockLight.g, light.blockLight.b)), 0.0, 1.0);
}

// Bruit deterministe (aucune texture a lire : tout est procedural).
fn ghHash(p: vec3f) -> f32 {
    return fract(sin(dot(p, vec3f(12.9898, 78.233, 37.719))) * 43758.5453);
}

// Epaisseur d'eau (en blocs) mesuree avec la texture de profondeur de scene.
// Disponible uniquement dans les variantes "liquid" (BLOXD_SCENE_DEPTH).
// Appelable depuis les hooks surface et light, jamais depuis un vertex hook.
fn ghWaterThicknessAt(position: vec3f) -> f32 {
#ifdef BLOXD_SCENE_DEPTH
    let behind = bloxdOpaqueBehind();
    if (behind.hit) {
        return clamp(behind.distance - distance(bloxdEyePosition(), position), 0.0, 12.0);
    }
    return 12.0;   // rien d'opaque derriere : eau "profonde" (ciel)
#else
    return 3.0;    // repli : aucune information de profondeur
#endif
}

// Etincelle deterministe (minerais) : chaque cellule scintille a son rythme.
fn ghSparkle(worldPos: vec3f, seed: f32, t: f32) -> f32 {
    let cell = floor(worldPos * 5.0) + vec3f(seed);
    let rnd = ghHash(cell);
    let phase = fract(t * 0.40 + rnd);
    let blink = pow(max(0.0, sin(phase * 6.2831853)), 40.0);
    return blink * step(0.62, rnd);
}
