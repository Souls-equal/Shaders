// ============================================================================
//  30-vertex.wgsl : animation de sommets - jeux "allow" uniquement.
//  Un vertex hook defini dans une variante "strict" desactive TOUT le pack :
//  chaque hook est donc entoure de #ifndef BLOXD_STRICT.
// ============================================================================

#ifndef BLOXD_STRICT
// Vent dans les feuilles / herbes hautes : on ne bouge que le haut des quads
// (les sommets dont la normale n'est pas verticale), proportionnellement a la
// hauteur locale du sommet dans son bloc.
fn bloxdTerrainVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);

    // Uniquement la vegetation (feuilles, herbes) : les blocs pleins restent nets.
    if (vertex.flags.vegetation || vertex.flags.flat) {
        let worldPos = bloxdWorldPosition(vertex.position);
        let t = bloxdSeconds();
        // hauteur dans le bloc : 0 en bas, 1 en haut (les quads de feuilles
        // ont des sommets a y entier, on prend la fraction).
        let top = fract(worldPos.y);
        let lift = smoothstep(0.05, 0.95, top);

        let phase = worldPos.x * 0.55 + worldPos.z * 0.47;
        let gust = 0.65 + 0.35 * sin(t * 0.31 + worldPos.x * 0.03);

        let sx = sin(t * ghSwaySpeed + phase) * ghSwayAmount * lift * gust;
        let sz = cos(t * 0.83 * ghSwaySpeed + phase * 1.31) * ghSwayAmount * 0.6 * lift * gust;

        out.position.x += sx;
        out.position.z += sz;
        out.position.y += (abs(sx) + abs(sz)) * -0.25;   // leger tassement
    }

    return out;
}
#endif
