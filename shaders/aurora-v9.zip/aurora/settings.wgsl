// ═══════════════════════════════════════════════════════════════════════════
//  AURORA — réglages
//  Tout ce qui se règle est ici. Mettre une force à 0.0 désactive l'effet.
// ═══════════════════════════════════════════════════════════════════════════

// ── Étalonnage des couleurs (appliqué à tout, après l'éclairage) ───────────
const EXPOSURE: f32 = 1.10;          // Luminosité avant la courbe filmique.
const WHITE_POINT: f32 = 1.6;        // Luminosité qui devient blanc pur.
const TONEMAP_MIX: f32 = 0.55;       // 0 = pas de courbe filmique, 1 = totale.
const CONTRAST: f32 = 0.16;          // 0 = normal, 1 = extrême.
const SATURATION: f32 = 1.14;        // Multiplicateur de saturation.
const SHADOW_TINT = vec3f(0.93, 0.98, 1.07);  // Les ombres tirent vers le froid.
const LIGHT_TINT = vec3f(1.05, 1.02, 0.95);   // Les lumières tirent vers le chaud.

// ── Moment de la journée ───────────────────────────────────────────────────
const GOLDEN_TINT = vec3f(1.14, 0.94, 0.78);  // Teinte à l'aube et au crépuscule.
const GOLDEN_AMOUNT: f32 = 0.8;
const NIGHT_TINT = vec3f(0.62, 0.78, 1.12);   // Teinte lunaire de la nuit.
const NIGHT_AMOUNT: f32 = 0.5;
const NIGHT_DESATURATE: f32 = 0.25;
const MOON_STRENGTH: f32 = 0.3;               // Force de la « lumière » de lune.
const FALLBACK_LIGHT = vec3f(0.424, 0.848, 0.318); // Direction si le jeu n'a pas de soleil.

// ── Brume et ciel ──────────────────────────────────────────────────────────
const FOG_SUN_SCATTER: f32 = 0.55;   // La brume s'illumine face au soleil.
const FOG_SUN_POWER: f32 = 5.0;      // Plus haut = halo plus serré.
const SKY_HORIZON = vec3f(0.78, 0.86, 0.96);
const SKY_ZENITH = vec3f(0.30, 0.52, 0.92);

// ── Relief des textures (faux normal-mapping depuis la luminosité) ─────────
const BUMP_STRENGTH: f32 = 1.1;      // Profondeur du relief.
const BUMP_SUN: f32 = 0.9;           // Influence du soleil sur le relief.
const BUMP_CREVICE: f32 = 0.6;       // Assombrissement des creux.
const BUMP_FADE_START: f32 = 20.0;   // Le relief s'estompe entre ces
const BUMP_FADE_END: f32 = 56.0;     // deux distances (en blocs).

// ── Ombres (approchées : l'API n'offre pas de vraies ombres portées) ───────
const SHADOW_OCCLUSION: f32 = 0.8;   // Ombre sous les arbres, auvents, surplombs.
const SHADOW_SKY_START: f32 = 0.88;  // Sous ce niveau de lumière du ciel, c'est de l'ombre.
const SHADOW_DAPPLE: f32 = 0.6;      // Taches de lumière qui bougent sous les feuillages.
const SHADOW_GOLDEN_BOOST: f32 = 0.4; // Ombres plus marquées quand le soleil est bas.
const SHADOW_FORM: f32 = 0.35;       // Faces opposées au soleil plus sombres.
const SHADOW_CLOUD: f32 = 0.5;       // Ombres de nuages qui défilent sur le sol.
const CLOUD_SCALE: f32 = 0.025;      // Taille des nuages (plus petit = plus grands).
const CLOUD_SPEED: f32 = 1.2;        // Vitesse de défilement, en blocs par seconde.
const CLOUD_HEIGHT: f32 = 140.0;     // Hauteur des nuages reflétés dans l'eau (blocs).
const CLOUD_REFLECTION: f32 = 1.0;   // Force des nuages dans les reflets (0 = aucun).
const SHADOW_CAST_TINT = vec3f(0.55, 0.65, 0.85);  // Couleur de l'ombre la plus forte (froide).

// ── Brillance et scintillements ────────────────────────────────────────────
const SPEC_STRENGTH: f32 = 1.0;      // Reflets du soleil (glace, métaux, gemmes…).
const SPARKLE_STRENGTH: f32 = 0.7;   // Éclats sur minerais, neige, glace, gemmes.

// ── Végétation ─────────────────────────────────────────────────────────────
const SWAY_AMPLITUDE: f32 = 0.17;    // Balancement au vent (blocs).
const GUST_STRENGTH: f32 = 0.7;      // Les rafales varient la force du vent.
const LEAF_VARIATION: f32 = 0.10;    // Variation de teinte d'un bloc de feuilles à l'autre.
const GRASS_VARIATION: f32 = 0.06;   // Idem pour l'herbe.
const LEAF_SHIMMER: f32 = 0.6;       // Les feuilles ondulent et scintillent (marche aussi en jeu strict).
const LEAF_WOBBLE: f32 = 0.035;      // Amplitude de l'ondulation de la texture.
const LEAF_TRANSLUCENCY: f32 = 0.6;  // Les feuilles brillent à contre-jour.

// ── Lueurs ─────────────────────────────────────────────────────────────────
const EMISSIVE_BOOST: f32 = 0.45;       // Blocs lumineux : surcroît de lueur.
const EMISSIVE_NIGHT_BOOST: f32 = 0.6;  // Lueurs plus fortes de nuit / en grotte.
const NEON_GLOW: f32 = 0.5;             // Néons, lampes, glowstone.
const PORTAL_GLOW: f32 = 0.6;
const LAVA_GLOW: f32 = 0.55;
const LAVA_PULSE: f32 = 0.3;            // La lave « respire ».
const ENCHANT_GLOW: f32 = 0.35;         // Éclat des objets enchantés.
const RIM_STRENGTH: f32 = 0.28;         // Liseré de lumière sur joueurs et mobs.

// ── Eau ────────────────────────────────────────────────────────────────────
const DEFAULT_TINT = vec3f(0.5, 0.5, 0.8);     // Teinte d'origine de l'eau du moteur.
const SHALLOW_TINT = vec3f(0.22, 0.68, 0.70);  // Eau peu profonde.
const DEEP_TINT = vec3f(0.05, 0.18, 0.42);     // Eau profonde.
const COLOUR_DENSITY: f32 = 0.32;    // Vitesse à laquelle l'eau fonce avec la profondeur.
const SHALLOW_ALPHA: f32 = 0.5;      // Opacité (× opacité d'origine) en surface.

const HEAD_ON_REFLECTION: f32 = 0.03;  // Reflet du ciel vu de dessus.
const GRAZING_REFLECTION: f32 = 0.60;  // Reflet du ciel en rasant.
const INDOOR_SKY_LIGHT: f32 = 0.45;    // Pas de reflet en dessous.
const OUTDOOR_SKY_LIGHT: f32 = 0.98;   // Reflet complet au-dessus.

const GLINT_BRIGHTNESS: f32 = 0.30;    // Scintillement du soleil (ou de la lune).
const GLINT_SHARPNESS: f32 = 220.0;
const GLINT_ALPHA: f32 = 0.6;
const GLINT_FADE_SUN_Y: f32 = 0.25;

const CELLS_PER_BLOCK: f32 = 8.0;      // Résolution (pixelisée) des vagues.
const CELLS_I: i32 = 8;                // Même valeur, en entier.
const SIDE_RIPPLE: f32 = 0.25;
const FLAT_CELL_PIXELS: f32 = 0.05;    // Anti-scintillement à distance.
const FULL_CELL_PIXELS: f32 = 0.2;
const WAVE_NORMAL: f32 = 1.0;          // Force des vagues sur la lumière.
const WAVE_CHAOS: f32 = 0.4;           // 0 = vagues régulières, 1 = très variables. Garder bas.
const WAVE_VERTEX: f32 = 0.28;         // Hauteur réelle des vagues (0 = surface plate).

const UNDER_TINT = vec3f(0.12, 0.50, 0.62);  // Teinte de la surface vue d'en dessous.
const UNDER_TINT_AMOUNT: f32 = 0.5;
const UNDER_ALPHA: f32 = 0.22;         // Opacité sous l'eau (plus bas = plus transparent).
const UNDER_CAUSTIC: f32 = 0.45;       // Reflets de lumière sur la surface vue d'en bas.

const FOAM_DEPTH: f32 = 0.45;          // Écume près des rives (profondeur en blocs).
const FOAM_STRENGTH: f32 = 0.85;
const FOAM_SCALE: f32 = 1.9;
const CAUSTIC_STRENGTH: f32 = 0.22;    // Reflets de lumière sur les petits fonds.
const CAUSTIC_SCALE: f32 = 1.3;
