// Aurora — eau : vagues, reflets du ciel, scintillement, profondeur, écume,
// caustiques. La lave passe aussi par les hooks de liquide.

// Une vague : x = hauteur, y et z = pente selon x et z.
fn waveTerm(point: vec2f, t: f32, dir: vec2f, k: f32, speed: f32, amplitude: f32) -> vec3f {
    let phase = (dot(point, dir) * k + t * speed) % bloxdTau;
    let slope = amplitude * k * cos(phase);
    return vec3f(amplitude * sin(phase), slope * dir.x, slope * dir.y);
}

// Les vagues varient seulement par leur force (bruit très lent et très large)
// et par un léger changement de direction dans le TEMPS, identique partout.
// Ne jamais faire dépendre la direction ou la position de la phase d'une
// vague du lieu : avec de grandes coordonnées, ça crée des anneaux de moiré.
fn waveDir(baseAngle: f32, seed: f32, t: f32) -> vec2f {
    let angle = baseAngle + sin((t * 0.04 + seed * 9.0) % bloxdTau) * 0.3 * WAVE_CHAOS;
    return vec2f(cos(angle), sin(angle));
}

// Force d'une vague : varie doucement d'une zone à l'autre (~30 blocs).
fn waveGain(seed: f32, point: vec2f, t: f32) -> f32 {
    let n = valueNoise3(vec3f(point * 0.035 + seed * 13.0, t * 0.03 + seed));
    return mix(1.0, 0.6 + 0.8 * n, WAVE_CHAOS);
}

// Trois vagues larges et une petite, qui se croisent. `detail` (0 à 1) fait
// disparaître la petite vague de loin, là où elle ferait du moiré.
fn waveField(point: vec2f, detail: f32) -> vec3f {
    let t = bloxdSeconds();
    var field = waveTerm(point, t, waveDir(0.46, 0.1, t), 1.3, 0.9, 0.060 * waveGain(0.1, point, t));
    field += waveTerm(point, t, waveDir(1.75, 0.3, t), 2.1, 1.2, 0.036 * waveGain(0.3, point, t));
    field += waveTerm(point, t, waveDir(-0.85, 0.5, t), 3.3, 1.6, 0.020 * waveGain(0.5, point, t)) * detail;
    return field;
}

// What the surface hook found, for the light hook of the same fragment.
struct WaterState {
    normal: vec3f,
    toEye: vec3f,
    fresnel: f32,
    glint: f32,
    below: f32, // 1 quand on voit l'eau depuis dessous (caméra sous l'eau).
}
var<private> waterState: WaterState;

fn waterSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    let sun = sunInfo();
    let t = bloxdSeconds();

    // Move half a cell into the block to prevent flickering on side faces.
    let cell = floor(surface.position * CELLS_PER_BLOCK - surface.normal * 0.5);

    // Integer world cells, so waves don't jump during render offset changes.
    let worldCell = vec3i(cell).xz + bloxdRenderOffset().xz * CELLS_I;
    let cellWorld = (vec2f(worldCell) + 0.5) / CELLS_PER_BLOCK;

    // Pixels across a cell on screen; tiny cells fade flat to avoid flicker.
    let cellPixels = 1.0 / (length(fwidth(surface.position)) * CELLS_PER_BLOCK);
    let rippling = smoothstep(FLAT_CELL_PIXELS, FULL_CELL_PIXELS, cellPixels);

    // Les vagues inclinent la normale : la surface elle-même reste plate.
    let slope = waveField(cellWorld, rippling).yz;
    let strength = mix(SIDE_RIPPLE, 1.0, saturate(surface.normal.y)) * rippling * WAVE_NORMAL;
    let normal = normalize(surface.normal - vec3f(slope.x, 0.0, slope.y) * strength);

    // Profondeur : du rivage (0) vers le large (1). Le ciel derrière = profond.
    var behindHit = false;
    var behindY = 0.0;
#ifdef BLOXD_SCENE_DEPTH
    let behind = bloxdOpaqueBehind();
    behindHit = behind.hit;
    behindY = behind.position.y;
#endif
    let blocksDeep = select(99.0, max(surface.position.y - behindY, 0.0), behindHit);
    let depth = 1.0 - exp(-blocksDeep * COLOUR_DENSITY);

    // Fresnel de Schlick et reflet du soleil, depuis le centre de la cellule.
    let toEye = normalize(bloxdEyePosition() - (cell + 0.5) / CELLS_PER_BLOCK);

    // Vue depuis dessous : la face de l'eau tourne le dos à la caméra.
    let below = select(0.0, 1.0, dot(surface.normal, toEye) < 0.0);
    let fresnel = pow(1.0 - saturate(dot(toEye, normal)), 5.0);
    let halfway = toEye + sun.direction;
    // Not normalize(halfway), which is NaN for a sun exactly behind the water.
    let facing = saturate(dot(normal, halfway) / max(length(halfway), 0.0001));
    let lightUp = saturate(sun.direction.y / GLINT_FADE_SUN_Y);
    let glint = GLINT_BRIGHTNESS * pow(facing, GLINT_SHARPNESS) * lightUp * sun.strength * (1.0 - below);

    // Écume près des rives, par taches qui bougent.
    let topFace = step(0.5, surface.normal.y);
    let shore = (1.0 - smoothstep(0.0, FOAM_DEPTH, blocksDeep)) * topFace;
    let foamNoise = valueNoise3(vec3f(cellWorld * FOAM_SCALE, t * 0.45));
    let foam = shore * smoothstep(0.32, 0.55, foamNoise) * FOAM_STRENGTH * (1.0 - below);

    // Caustiques : des lignes de lumière sur l'eau peu profonde.
    let causticNoise = valueNoise3(vec3f(cellWorld * CAUSTIC_SCALE, t * 0.35));
    let caustic = pow(1.0 - abs(2.0 * causticNoise - 1.0), 6.0)
        * (1.0 - depth) * topFace * CAUSTIC_STRENGTH;

    // Teinte selon la profondeur, à la place de la teinte d'origine.
    let tint = mix(SHALLOW_TINT, DEEP_TINT, depth);
    let water = surface.colour / DEFAULT_TINT * tint;
    // Sous l'eau : une teinte plus douce, au lieu d'un voile bleu opaque.
    let top = mix(water, vec3f(1.0), foam);
    out.colour = mix(top, UNDER_TINT, below * UNDER_TINT_AMOUNT);
#ifdef BLOXD_ALPHA
    // Peu profonde = plus transparente, mais l'écume et les reflets restent.
    let alphaTop = saturate(max(surface.alpha * mix(SHALLOW_ALPHA, 1.0, depth), foam * 0.92)
        + glint * GLINT_ALPHA);
    // De dessous, la surface est presque transparente, sauf en rasant, où elle
    // devient un miroir argenté (réflexion totale).
    let mirror = smoothstep(0.55, 0.85, 1.0 - abs(dot(toEye, normal)));
    let alphaUnder = mix(UNDER_ALPHA, 0.92, mirror);
    out.alpha = mix(alphaTop, alphaUnder, below);
#endif
    // Reflets de lumière : sur le fond vu d'en haut, sur la surface vue d'en bas.
    let underCaustic = pow(1.0 - abs(2.0 * causticNoise - 1.0), 6.0) * UNDER_CAUSTIC;
    out.emission = vec3f(0.55, 0.85, 1.0) * mix(caustic, underCaustic, below);

    waterState = WaterState(normal, toEye, fresnel, glint, below);
    return out;
}

fn liquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    // Derivatives in waterSurface come before the lava branch below.
    let water = waterSurface(surface);
    if (surface.textureId == bloxdTextureIdLava) {
        var lava = bloxdDefaultSurface(surface);
        let texelLuminance = luminance(surface.colour);
        lava.emission = lavaEmission(surface, texelLuminance);
        return lava;
    }
    return water;
}

fn liquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    let sun = sunInfo();
    if (light.textureId == bloxdTextureIdLava) {
        return withColour(surface, light, finishColour(light.litColour, surface.emission, light, sun));
    }

    // Le ciel se reflète dans les vagues, surtout en rasant, jamais à l'intérieur.
    let sky = smoothstep(INDOOR_SKY_LIGHT, OUTDOOR_SKY_LIGHT, light.skyLight);
    let reflected = reflect(-waterState.toEye, waterState.normal);
    let direction = normalize(vec3f(reflected.x, max(reflected.y, 0.03), reflected.z));
    let skyColour = skyGradient(direction, sun) * light.skyLightColour;
    let amount = mix(HEAD_ON_REFLECTION, GRAZING_REFLECTION, waterState.fresnel) * sky * (1.0 - waterState.below);

    var colour = mix(light.litColour, skyColour, amount);
    colour += sun.colour * waterState.glint * sky;
    return withColour(surface, light, finishColour(colour, surface.emission, light, sun));
}

// ── Mouvement réel de la surface (désactivé dans les jeux stricts) ─────────

fn liquidHeight(position: vec3f, glowing: bool) -> f32 {
    let world = bloxdWorldPosition(position);
    let wave = waveField(world.xz, 1.0).x * WAVE_VERTEX;
    let bob = sin((world.x * 0.8 + world.z * 0.6 + bloxdSeconds() * 0.9) % bloxdTau) * 0.02;
    return select(wave, bob, glowing);
}
