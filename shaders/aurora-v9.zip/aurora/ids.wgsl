// Généré depuis BLOCK_TEXTURES.md : familles de textures utilisées par Aurora.

fn isOre(id: u32) -> bool {
    return id == bloxdTextureIdCoalOre
        || id == bloxdTextureIdCometOre
        || id == bloxdTextureIdCopperOre
        || id == bloxdTextureIdDiamondOre
        || id == bloxdTextureIdEmeraldOre
        || id == bloxdTextureIdGoldOre
        || id == bloxdTextureIdIronOre
        || id == bloxdTextureIdLapisOre
        || id == bloxdTextureIdLuniteOre
        || id == bloxdTextureIdMoonstoneOre
        || id == bloxdTextureIdPureCoalOre
        || id == bloxdTextureIdPureCopperOre
        || id == bloxdTextureIdPureDiamondOre
        || id == bloxdTextureIdPureGoldOre
        || id == bloxdTextureIdPureIronOre
        || id == bloxdTextureIdPureMoonstoneOre
        || id == bloxdTextureIdPureVoltiteOre
        || id == bloxdTextureIdVoltiteOre;
}

fn isPortal(id: u32) -> bool {
    return id == bloxdTextureIdBlackPortal
        || id == bloxdTextureIdBluePortal
        || id == bloxdTextureIdBrownPortal
        || id == bloxdTextureIdCyanPortal
        || id == bloxdTextureIdGrayPortal
        || id == bloxdTextureIdGreenPortal
        || id == bloxdTextureIdGreyPortal
        || id == bloxdTextureIdLightbluePortal
        || id == bloxdTextureIdLightgrayPortal
        || id == bloxdTextureIdLimePortal
        || id == bloxdTextureIdMagentaPortal
        || id == bloxdTextureIdOrangePortal
        || id == bloxdTextureIdPinkPortal
        || id == bloxdTextureIdPurplePortal
        || id == bloxdTextureIdRedPortal
        || id == bloxdTextureIdWhitePortal
        || id == bloxdTextureIdYellowPortal;
}

fn isNeon(id: u32) -> bool {
    return id == bloxdTextureIdNeonBlack
        || id == bloxdTextureIdNeonBlue
        || id == bloxdTextureIdNeonBrown
        || id == bloxdTextureIdNeonCyan
        || id == bloxdTextureIdNeonGray
        || id == bloxdTextureIdNeonGreen
        || id == bloxdTextureIdNeonLightBlue
        || id == bloxdTextureIdNeonLightGray
        || id == bloxdTextureIdNeonLime
        || id == bloxdTextureIdNeonMagenta
        || id == bloxdTextureIdNeonOrange
        || id == bloxdTextureIdNeonPink
        || id == bloxdTextureIdNeonPurple
        || id == bloxdTextureIdNeonRed
        || id == bloxdTextureIdNeonWhite
        || id == bloxdTextureIdNeonYellow;
}

fn isGlass(id: u32) -> bool {
    return id == bloxdTextureIdGlass
        || id == bloxdTextureIdGlassBlack
        || id == bloxdTextureIdGlassBlue
        || id == bloxdTextureIdGlassBrown
        || id == bloxdTextureIdGlassCyan
        || id == bloxdTextureIdGlassGray
        || id == bloxdTextureIdGlassGreen
        || id == bloxdTextureIdGlassLightBlue
        || id == bloxdTextureIdGlassLightGray
        || id == bloxdTextureIdGlassLime
        || id == bloxdTextureIdGlassMagenta
        || id == bloxdTextureIdGlassOrange
        || id == bloxdTextureIdGlassPink
        || id == bloxdTextureIdGlassPurple
        || id == bloxdTextureIdGlassRed
        || id == bloxdTextureIdGlassSilver
        || id == bloxdTextureIdGlassWhite
        || id == bloxdTextureIdGlassYellow
        || id == bloxdTextureIdPatternedGlassBlack
        || id == bloxdTextureIdPatternedGlassBlue
        || id == bloxdTextureIdPatternedGlassBrown
        || id == bloxdTextureIdPatternedGlassCyan
        || id == bloxdTextureIdPatternedGlassGray
        || id == bloxdTextureIdPatternedGlassGreen
        || id == bloxdTextureIdPatternedGlassLightBlue
        || id == bloxdTextureIdPatternedGlassLightGray
        || id == bloxdTextureIdPatternedGlassLime
        || id == bloxdTextureIdPatternedGlassMagenta
        || id == bloxdTextureIdPatternedGlassOrange
        || id == bloxdTextureIdPatternedGlassPink
        || id == bloxdTextureIdPatternedGlassPurple
        || id == bloxdTextureIdPatternedGlassRed
        || id == bloxdTextureIdPatternedGlassWhite
        || id == bloxdTextureIdPatternedGlassYellow;
}

fn isMetalBlock(id: u32) -> bool {
    return id == bloxdTextureIdGoldBlock
        || id == bloxdTextureIdIronBlock
        || id == bloxdTextureIdLapisBlock
        || id == bloxdTextureIdLuniteBlock
        || id == bloxdTextureIdMoonstoneBlock;
}

fn isGemBlock(id: u32) -> bool {
    return id == bloxdTextureIdCrystalBlock
        || id == bloxdTextureIdDiamondBlock
        || id == bloxdTextureIdEmeraldBlock
        || id == bloxdTextureIdBeacon;
}

fn isIce(id: u32) -> bool {
    return id == bloxdTextureIdIce
        || id == bloxdTextureIdIceBrick
        || id == bloxdTextureIdMeltingIce;
}

fn isSnow(id: u32) -> bool {
    return id == bloxdTextureIdSnow
        || id == bloxdTextureIdPackedSnow;
}

fn isLamp(id: u32) -> bool {
    return id == bloxdTextureIdGlowstone
        || id == bloxdTextureIdRedstoneLampOn
        || id == bloxdTextureIdPumpkinFaceOn
        || id == bloxdTextureIdBeacon;
}

fn isLavaLike(id: u32) -> bool {
    return id == bloxdTextureIdMagma
        || id == bloxdTextureIdDarkstoneBricksLava;
}

fn isSand(id: u32) -> bool {
    return id == bloxdTextureIdSand
        || id == bloxdTextureIdRedSand;
}
