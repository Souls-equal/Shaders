// ═══════════════════════════════════════════════════════════════════════════
//  AURORA — shader pack complet
//  Étalonnage filmique, relief des textures, eau et lave animées, végétation
//  vivante, lueurs, brume solaire, cycle jour/nuit.
//  Réglages : settings.wgsl.
// ═══════════════════════════════════════════════════════════════════════════

// ── Vent ───────────────────────────────────────────────────────────────────

// Leaves and plants are vegetation, like grass blocks, but those are dirt too.
fn sways(flags: BloxdFlags) -> bool {
    return flags.vegetation && !flags.dirt;
}

// The wind's displacement at a render position.
fn wind(position: vec3f) -> vec3f {
    // World position, so the pattern doesn't jump during render offset changes.
    let world = bloxdWorldPosition(position);
    let t = bloxdSeconds();

    // Les rafales passent en vagues lentes à travers le paysage.
    let drift = world.xz * 0.07 + vec2f(t * 0.35, t * 0.2);
    let gust = mix(1.0 - GUST_STRENGTH * 0.5, 1.0 + GUST_STRENGTH,
        valueNoise3(vec3f(drift, t * 0.1)));

    let phase = dot(world.xz, vec2f(0.7, 0.5));
    let sway = sin((phase + t * 1.7) % bloxdTau)
        + 0.45 * sin((phase * 2.1 + t * 3.3) % bloxdTau);
    let sideways = sin((phase * 0.8 + t * 1.3 + 1.9) % bloxdTau)
        + 0.45 * sin((phase * 1.7 + t * 2.7 + 0.6) % bloxdTau);
    // Un léger mouvement vertical, pour que le feuillage « respire ».
    let bob = 0.3 * sin((phase * 1.3 + t * 2.3 + 0.8) % bloxdTau);
    return vec3f(sway, bob, sideways) * (SWAY_AMPLITUDE * gust / 1.45);
}

// ── Vertex : strict games prevent vertex movement ──────────────────────────
// Sans le #ifndef, ces hooks désactiveraient tout le pack dans ces jeux.
#ifndef BLOXD_STRICT
fn bloxdTerrainVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    if (sways(vertex.flags)) {
        out.position += wind(vertex.position);
    }
    return out;
}

// Plants are block models. The top sways, anchored to the fixed bottom.
fn bloxdModelVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    // Held or dropped plants shouldn't sway.
    if (sways(vertex.flags) && vertex.flags.placed) {
        let height = vertex.localPosition.y + 0.5;
        out.position += wind(vertex.position) * clamp(height, 0.0, 1.0);
    }
    return out;
}

fn bloxdLiquidVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    if (vertex.normal.y > 0.5) {
        out.position.y += liquidHeight(vertex.position, vertex.flags.emissive);
    }
    return out;
}
#endif

// ── Surface ────────────────────────────────────────────────────────────────

fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return auroraSurface(surface);
}

fn bloxdModelSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return auroraSurface(surface);
}

fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return liquidSurface(surface);
}

// ── Lumière ────────────────────────────────────────────────────────────────

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return auroraLight(surface, light);
}

fn bloxdModelLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return auroraLight(surface, light);
}

fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return liquidLight(surface, light);
}
