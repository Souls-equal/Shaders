// ============================================================================
//  Emberfall - pack de shaders Bloxd.io (API v5, WebGPU)
//  01-config.wgsl : reglages du theme "nether / enfer"
//  Identifiants reserves : tout ce qui commence par "bloxd" appartient au
//  moteur. Les helpers de ce pack utilisent le prefixe "ef".
// ============================================================================

// --- Etalonnage : basse cle, tres contraste, chaud
const efExposure: f32 = 1.14;
const efSaturation: f32 = 1.22;
const efContrast: f32 = 1.12;
const efLift: f32 = 0.10;            // remontee des noirs (rouge sombre, jamais noir)

// --- Palette "nether" pilotee par les flags des blocs
const efRockColour: vec3f = vec3f(0.46, 0.17, 0.14);   // roche / soul sand
const efDirtColour: vec3f = vec3f(0.40, 0.19, 0.12);   // terre, herbes brulees
const efSandColour: vec3f = vec3f(0.52, 0.26, 0.15);
const efRockAmount: f32 = 0.62;      // part de la teinte appliquee (1 = repeint)
const efEmberBleed: f32 = 0.55;      // lueur orange que la roche renvoie

// --- Lumiere : soleil ecrase (on est sous terre), tout vient du feu
const efSunKill: f32 = 0.72;         // 1 = ignore completement le soleil
const efFireWarm: vec3f = vec3f(1.24, 0.74, 0.40);
const efFireHot: vec3f = vec3f(1.40, 0.92, 0.52);
const efAmbient: vec3f = vec3f(0.085, 0.042, 0.035);

// --- Lave et braises (hook light, lave = flags.emissive)
const efLavaGlow: f32 = 0.85;        // halo autour des blocs de lave
const efLavaPulse: f32 = 0.16;       // respiration lente de la lave
const efHeatShimmer: f32 = 0.006;    // tremblement de l'air au-dessus du feu

// --- Braises volantes (hook light, comme les flocons de Frostbound)
const efEmberAmount: f32 = 0.85;
const efEmberRange: f32 = 30.0;
const efEmberRise: f32 = 1.5;        // vitesse de montee

// --- Atmosphere : brume de cendres, dense et basse
const efHazeColour: vec3f = vec3f(0.44, 0.20, 0.13);
const efHazeDensity: f32 = 0.0125;
const efHazeMax: f32 = 0.92;
const efHazeFloor: f32 = 0.35;       // la brume s'accumule pres du sol
const efHazeFloorY: f32 = 18.0;      // hauteur au-dessus de laquelle la brume se dissipe

// --- Lave liquide (programme liquid)
const efLavaColour: vec3f = vec3f(1.00, 0.38, 0.06);
const efLavaCrust: vec3f = vec3f(0.16, 0.05, 0.03);
const efLavaSpeed: f32 = 0.55;
const efLavaScale: f32 = 0.55;
const efLavaOpacity: f32 = 1.00;

// --- Vegetation (hooks vertex, jeux "allow" uniquement)
const efSwayAmount: f32 = 0.045;
const efSwaySpeed: f32 = 2.6;
