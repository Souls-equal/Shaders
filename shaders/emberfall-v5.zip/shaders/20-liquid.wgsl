// ============================================================================
//  Emberfall - 20-liquid.wgsl : programme "liquid" = flaque de lave
//  La lave est un fluide chaud : on lui donne une croute qui derive, des
//  fractures incandescentes, et une lueur qui ne depend pas du soleil.
// ============================================================================

// Champ de lave : deux fbm en mouvement + une croute qui craquelle.
// Renvoie une valeur 0 (croute) .. 1 (fonte incandescente).
fn efLavaField(worldPos: vec3f, t: f32) -> f32 {
    let p = vec2f(worldPos.x, worldPos.z) * efLavaScale;
    // Deux couches qui glissent dans des directions differentes.
    let a = efFbm(p + vec2f(t * efLavaSpeed, t * efLavaSpeed * 0.6));
    let b = efFbm(p * 1.7 - vec2f(t * efLavaSpeed * 0.8, t * efLavaSpeed * 1.1) + vec2f(5.0, 9.0));
    let heat = clamp(a * 0.65 + b * 0.35, 0.0, 1.0);

    // Grandes plaques de croute qui refroidissent : chaque zone a sa temperature.
    let plate = efNoise(vec2f(worldPos.x, worldPos.z) * 0.16 + vec2f(t * 0.03, 0.0));
    // Les fractures : la ou le champ passe un seuil, la croute se fend.
    let crack = smoothstep(0.50, 0.64, heat) * (0.60 + 0.40 * plate);
    // Pulsation globale tres lente (respiration du flot).
    let pulse = 0.92 + 0.08 * sin(t * 0.7 + worldPos.x * 0.2 + worldPos.z * 0.25);
    return clamp(mix(0.10, 1.0, crack) * pulse, 0.0, 1.0);
}

// --------------------------------------------------------- houle (vertex) ---
// La lave est visqueuse : ondulation lente et large, uniquement en "allow".
#ifndef BLOXD_STRICT
fn bloxdLiquidVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    let topness = clamp(vertex.normal.y * 2.0, 0.0, 1.0);
    if (topness > 0.001) {
        let wp = bloxdWorldPosition(vertex.position);
        let t = bloxdSeconds();
        let h = sin(wp.x * 0.5 + t * efLavaSpeed) * 0.035
              + sin(wp.z * 0.37 - t * efLavaSpeed * 1.3) * 0.028;
        out.position.y += h * topness;
    }
    return out;
}
#endif

// --------------------------------------------------------------- surface ---
fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    let worldPos = bloxdWorldPosition(surface.position);
    let t = bloxdSeconds();

    let heat = efLavaField(worldPos, t);
    // Coeur incandescent -> croute sombre.
    let colour = mix(efLavaCrust, efLavaColour, heat);
    out.colour = colour;

    // La lave est son propre emissive : c'est ce qui la fait "briller" dans le noir.
    out.emission += mix(efLavaColour * 0.35, vec3f(1.0, 0.72, 0.28), heat) * (0.55 + 0.45 * heat);

#ifdef BLOXD_ALPHA
    out.alpha = efLavaOpacity;
#endif
    return out;
}

// ----------------------------------------------------------------- light ---
fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    if (!bloxdLit()) { return out; }

    let t = bloxdSeconds();
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let n = normalize(light.normal);
    let worldPos = bloxdWorldPosition(light.position);
    let dist = distance(bloxdEyePosition(), light.position);

    // La lave s'auto-eclaire : on n'utilise pas la lumiere du monde, qui
    // pourrait l'assombrir la nuit.
    let heat = efLavaField(worldPos, t);
    var colour = mix(efLavaCrust, efLavaColour, heat);

    // Halo chaud au centre des fractures.
    colour += vec3f(1.0, 0.68, 0.24) * (pow(heat, 3.0) * 0.35);

    // Reflet rasant : la surface fondue renvoie le ciel rougeatre.
    let fresnel = pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 3.0);
    colour = mix(colour, vec3f(0.85, 0.35, 0.15), fresnel * 0.35);

    // Un peu de lumiere de bloc ambiante adoucit la lave dans une piece eclairee.
    let fire = efBlockLight(light);
    colour += efFireHot * (fire * 0.06);

    // Brume + etalonnage + braises, comme le terrain.
    let haze = efHaze(dist, worldPos.y, light.fogAlpha);
    colour = mix(colour, mix(light.fogColour, efHazeColour, 0.85), haze);
    colour = efGrade(colour, 1.0);
    let embers = efEmbers(light, t);
    if (embers > 0.001) {
        colour = mix(colour, vec3f(1.0, 0.55, 0.18), embers * 0.9);
    }

    out.colour = clamp(colour, vec3f(0.0), vec3f(1.0));
    return out;
}
