// ============================================================================
//  Emberfall - 10-terrain.wgsl : hooks surface + light du terrain et des modeles
// ============================================================================

// ---------------------------------------------------------------- surface --
// Le Nether n'a pas de neige : ici la surface repeint la matiere, cuit la roche
// pres du feu et fait pulser la lave.
fn efSurface(s: BloxdSurfaceIn, entity: bool) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    let worldPos = bloxdWorldPosition(s.position);
    let n = normalize(s.normal);
    let t = bloxdSeconds();

    // 1. Palette nether pilotee par les flags (sauf entites).
    if (!entity) {
        out.colour = efPalette(s.flags, out.colour);
    }

    // 2. Veines de cendre : un fbm sombre qui court sur la roche.
    if (s.flags.rock || s.flags.dirt) {
        let vein = efFbm(worldPos.xz * 0.7 + worldPos.y * 0.3);
        let ash = smoothstep(0.55, 0.85, vein);
        out.colour = mix(out.colour, out.colour * vec3f(0.45, 0.38, 0.36), ash * 0.55);
    }

    // 3. Blocs lumineux : lave, magma, glowstone. Ils pulsent lentement.
    if (s.flags.emissive) {
        let lum = efLuma(out.colour);
        let pulse = 1.0 + efLavaPulse * sin(t * 0.9 + worldPos.x * 0.35 + worldPos.z * 0.42);
        // Coeur jaune-blanc, bord orange : on pousse l'emission vers le haut.
        let hot = vec3f(1.0, 0.55, 0.18) * pulse;
        out.emission += (out.colour * 0.9 + hot * 0.35) * (lum * 0.9 + 0.25) * pulse;
        out.colour = mix(out.colour, vec3f(0.95, 0.42, 0.10), 0.35);
    }

    // 4. Croûte froide sur les faces tournees vers le bas.
    if (n.y < -0.5 && !s.flags.emissive) {
        out.colour *= vec3f(0.72, 0.66, 0.66);
    }

    return out;
}

// ------------------------------------------------------------------ light --
fn efLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    if (!bloxdLit()) { return out; }

    let t = bloxdSeconds();
    let n = normalize(light.normal);
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let worldPos = bloxdWorldPosition(light.position);
    let dist = distance(bloxdEyePosition(), light.position);

    let sunlit = efSunlit(light);
    let fire = efBlockLight(light);

    // --- 1. Le soleil est ecrase : on garde juste de quoi modeler ---------
    //     efSunKill = 1 -> eclairage totalement "feu".
    let daylight = bloxdLitColour(surface, light);
    let flame = bloxdWorldLight(light);   // lumiere du monde (feu inclus)
    var colour = daylight * mix(vec3f(1.0), flame, efSunKill * (0.55 + 0.45 * sunlit));

    // --- 2. Tout ce qui n'est pas eclaire par du feu rougit --------------
    let cold = 1.0 - clamp(fire + sunlit * (1.0 - efSunKill), 0.0, 1.0);
    colour = mix(colour, colour * vec3f(0.62, 0.34, 0.30) + efAmbient * 0.6, cold * 0.55);

    // --- 3. Pres du feu : lueur orange et coeur plus chaud ---------------
    if (fire > 0.001) {
        let heat = fire * fire;   // concentration pres de la source
        colour = mix(colour, colour * efFireWarm, 0.55 * fire);
        colour += efFireHot * (heat * efLavaGlow * 0.10);
        // Tremblement de l'air chaud : on decale la position d'echantillonnage
        // de la normale pour faire vibrer le modele d'eclairage.
        let wobble = sin(worldPos.y * 9.0 - t * 3.0) * efHeatShimmer * heat;
        colour += vec3f(wobble, wobble * 0.6, 0.0);
    }

    // --- 4. Reflet gras du feu sur les faces lisses ----------------------
    let fresnel = pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 4.0);
    colour += efFireWarm * (fresnel * 0.10 * (0.25 + 0.75 * fire));

    // --- 5. Emission de la surface (lave, magma) -------------------------
    colour += surface.emission * (1.0 - light.fogAlpha);

    // --- 6. Brume de cendres, dense et basse -----------------------------
    let haze = efHaze(dist, worldPos.y, light.fogAlpha);
    let hazeCol = mix(light.fogColour, efHazeColour, 0.85);
    colour = mix(colour, hazeCol, haze);

    // --- 7. Etalonnage chaud ---------------------------------------------
    colour = efGrade(colour, clamp(fire + sunlit * 0.4, 0.0, 1.0));

    // --- 8. Braises volantes par-dessus le tout --------------------------
    let embers = efEmbers(light, t);
    if (embers > 0.001) {
        let emberCol = mix(vec3f(1.0, 0.42, 0.10), vec3f(1.0, 0.78, 0.32), embers);
        colour = mix(colour, emberCol + colour * 0.25, embers);
    }

    out.colour = clamp(colour, vec3f(0.0), vec3f(1.0));
    return out;
}

// ----------------------------------------------------------------- terrain --
fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return efSurface(surface, false);
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return efLight(surface, light);
}

// ------------------------------------------------------------------- model --
fn bloxdModelSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return efSurface(surface, true);
}

fn bloxdModelLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return efLight(surface, light);
}
