// ============================================================================
//  Emberfall - 02-common.wgsl : briques partagees
// ============================================================================

fn efLuma(c: vec3f) -> f32 {
    return dot(c, vec3f(0.2126, 0.7152, 0.0722));
}

// Courbe de levage du skyLight du moteur, inversee (voir la doc API : sans
// cela, les ombres restent invisibles car skyLight vaut deja 0.97 sous un toit).
fn efUnlift(y: f32) -> f32 {
    let c = pow(clamp(1.0 - y, 0.0, 1.0), 1.0 / 3.0);
    return clamp(3.0 * (1.0 - c) / max(3.0 - 2.0 * c, 1e-4), 0.0, 1.0);
}

// Dans le Nether, "voir le ciel" ne veut rien dire : ce qui compte est de
// savoir si un bloc est eclaire par une source de feu a proximite.
fn efSunlit(light: BloxdLightIn) -> f32 {
    let raw = efUnlift(clamp(light.skyLight, 0.0, 1.0));
    return smoothstep(0.70, 0.88, raw);
}

fn efBlockLight(light: BloxdLightIn) -> f32 {
    return clamp(max(light.blockLight.r, max(light.blockLight.g, light.blockLight.b)), 0.0, 1.0);
}

// --- bruit ----------------------------------------------------------------
fn efHash13(p: vec3f) -> f32 {
    return fract(sin(dot(p, vec3f(127.1, 311.7, 74.7))) * 43758.5453);
}

fn efHash12(p: vec2f) -> f32 {
    return fract(sin(dot(p, vec2f(269.5, 183.3))) * 43758.5453);
}

fn efNoise(p: vec2f) -> f32 {
    let i = floor(p);
    let f = fract(p);
    let u = f * f * (3.0 - 2.0 * f);
    let a = efHash12(i);
    let b = efHash12(i + vec2f(1.0, 0.0));
    let c = efHash12(i + vec2f(0.0, 1.0));
    let d = efHash12(i + vec2f(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Bruit fractal : sert aux motifs de lave et aux veines de cendre.
fn efFbm(p: vec2f) -> f32 {
    var v = 0.0;
    var amp = 0.55;
    var q = p;
    for (var i = 0; i < 4; i++) {
        v += efNoise(q) * amp;
        q = q * 2.03 + vec2f(11.3, 7.7);
        amp *= 0.5;
    }
    return v;
}

// --- palette --------------------------------------------------------------
// Teinte "nether" d'une surface, choisie d'apres les flags du bloc (roche,
// terre, sable...). Le feuillage et les entites ne sont pas repeints.
fn efPalette(flags: BloxdFlags, base: vec3f) -> vec3f {
    var tinted = base;
    if (flags.rock) {
        tinted = efRockColour;
    } else if (flags.sand) {
        tinted = efSandColour;
    } else if (flags.dirt || flags.vegetation) {
        tinted = efDirtColour;
    } else {
        // Bois, verre, divers : on reste sur la couleur d'origine.
        return base;
    }
    // On garde une part de la texture d'origine pour ne pas tout uniformiser.
    return mix(base, base * 0.35 + tinted, efRockAmount);
}

// --- flamme ---------------------------------------------------------------
// Champ de "feu" procedural 2D : trois nappes d'octaves decalees vers le haut,
// ce qui donne des langues de flamme qui montent et se tordent.
fn efFlameField(uv: vec2f, t: f32) -> f32 {
    let rise = vec2f(0.0, -t * 1.6);
    let a = efFbm(uv * 2.2 + rise);
    let b = efFbm(uv * 3.7 + rise * 1.7 + vec2f(4.1, 1.3));
    let c = efNoise(uv * 7.0 + rise * 2.4);
    return clamp(a * 0.55 + b * 0.30 + c * 0.15, 0.0, 1.0);
}

// --- etincelles / braises -------------------------------------------------
// Secondes braises volantes : cellules animees qui montent autour de la camera.
fn efEmbers(light: BloxdLightIn, t: f32) -> f32 {
    let eye = bloxdEyePosition();
    let dist = distance(eye, light.position);
    if (dist > efEmberRange) { return 0.0; }

    var glow = 0.0;
    for (var layer = 0; layer < 2; layer++) {
        let lf = f32(layer);
        let scale = 1.1 + lf * 1.6;
        let p = bloxdWorldPosition(light.position)
              + vec3f(sin(t * 0.8 + lf * 1.7) * 1.4, t * efEmberRise * (1.0 + lf * 0.5), cos(t * 0.6 + lf * 2.3) * 1.4);
        let cell = floor(p * scale);
        let rnd = efHash13(cell + vec3f(lf * 5.1));
        if (rnd > 0.22) { continue; }
        let jitter = vec3f(
            efHash13(cell + vec3f(3.0, 11.0, 5.0)),
            efHash13(cell + vec3f(17.0, 2.0, 9.0)),
            efHash13(cell + vec3f(7.0, 23.0, 13.0))) - vec3f(0.5);
        let local = fract(p * scale) - vec3f(0.5) - jitter * 0.6;
        let size = 0.17 - lf * 0.05;
        let core = 1.0 - smoothstep(size * 0.25, size, length(local));
        // Flicker individuel : chaque braise a sa propre phase.
        let flicker = 0.55 + 0.45 * sin(t * 6.0 + rnd * 24.0);
        glow += core * flicker * (1.0 - lf * 0.45);
    }
    let nearFade = smoothstep(efEmberRange, efEmberRange * 0.35, dist);
    let closeFade = smoothstep(0.5, 2.0, dist);
    return clamp(glow * efEmberAmount * nearFade * closeFade, 0.0, 1.0);
}

// --- brume de cendres -----------------------------------------------------
// Contrairement a une brume classique, elle s'accumule pres du sol : on module
// l'opacite par la hauteur du fragment par rapport au sol de reference.
fn efHaze(dist: f32, worldY: f32, fogAlpha: f32) -> f32 {
    let base = clamp(1.0 - exp(-dist * efHazeDensity), 0.0, efHazeMax);
    let low = 1.0 - smoothstep(0.0, efHazeFloorY, max(worldY, 0.0));
    let floorBoost = efHazeFloor * low;
    return clamp(max(base + floorBoost * 0.5, fogAlpha * 0.9), 0.0, efHazeMax);
}

// --- etalonnage -----------------------------------------------------------
fn efGrade(colour: vec3f, fire: f32) -> vec3f {
    // 1. Exposition et saturation.
    var c = max(colour, vec3f(0.0)) * efExposure;
    c = mix(vec3f(efLuma(c)), c, efSaturation);

    // 2. Contraste en S, applique canal par canal puis adouci.
    let sc = clamp(c, vec3f(0.0), vec3f(1.0));
    let hard = sc * sc * (3.0 - 2.0 * sc);
    c = mix(sc, hard, efContrast - 0.55);

    // 3. Remontee des noirs vers un rouge sombre : jamais de noir pur.
    c = max(c, vec3f(efLift * 0.55, efLift * 0.16, efLift * 0.10));

    // 4. Le feu "brule" les hautes lumieres : elles tirent vers le jaune-blanc.
    let hot = smoothstep(0.55, 1.0, efLuma(c));
    c = mix(c, mix(c, efFireHot, 0.55), hot * (0.35 + 0.65 * fire));

    return clamp(c, vec3f(0.0), vec3f(1.0));
}
