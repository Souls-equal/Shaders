// ============================================================================
//  Emberfall - 30-vertex.wgsl : hooks vertex (jeux "allow" uniquement)
//  Le Nether est agite : les herbes brulent en tremblant, la roche "sue" la
//  chaleur par micro-vibrations tres lentes.
// ============================================================================

#ifndef BLOXD_STRICT
// Vegetation : tremblement nerveux (plus rapide et plus sec que du vent).
fn bloxdTerrainVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);

    if (vertex.flags.vegetation || vertex.flags.flat) {
        let worldPos = bloxdWorldPosition(vertex.position);
        let t = bloxdSeconds();
        let top = fract(worldPos.y);
        let lift = smoothstep(0.1, 0.95, top);

        let phase = worldPos.x * 0.9 + worldPos.z * 0.7;
        // Deux sinusoides de frequences differentes : ca tremble, ca n'oscille pas.
        let jitterX = sin(t * efSwaySpeed + phase) * 0.6 + sin(t * efSwaySpeed * 3.1 + phase * 2.0) * 0.4;
        let jitterZ = cos(t * efSwaySpeed * 0.87 + phase * 1.4);

        out.position.x += jitterX * efSwayAmount * lift;
        out.position.z += jitterZ * efSwayAmount * 0.7 * lift;
        // La chaleur fait "monter" legerement les sommets.
        out.position.y += sin(t * efSwaySpeed * 0.5 + phase) * efSwayAmount * 0.35 * lift;
    }

    return out;
}
#endif
