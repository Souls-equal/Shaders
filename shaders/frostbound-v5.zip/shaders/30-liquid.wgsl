// ============================================================================
//  Frostbound - 30-liquid.wgsl : programme "liquid" = eau gelee
//  L'eau devient une plaque de glace : peu de vagues, tres opaque, tres
//  reflechissante, avec des fissures visibles en profondeur.
// ============================================================================

// Albedo de la glace, avec un reseau de fissures procedural.
fn fbIceAlbedo(worldPos: vec3f, sunlit: f32) -> vec3f {
    // Bulles d'air prisonnieres : petites cellules claires eparses.
    let bubbles = smoothstep(0.985, 1.0, fbNoise(vec2f(worldPos.x * 6.0, worldPos.z * 6.0)));
    // Fissures : bruit etire sur une diagonale + un second a contre-sens.
    let a = fbNoise(vec2f(worldPos.x * 0.9 + worldPos.z * 0.4, worldPos.z * 0.9 - worldPos.x * 0.4));
    let b = fbNoise(vec2f(worldPos.x * 2.3 - worldPos.z * 1.1, worldPos.z * 2.3 + worldPos.x * 1.1));
    let cracks = smoothstep(0.62, 0.80, a) * 0.7 + smoothstep(0.70, 0.86, b) * 0.3;
    // La glace est plus blanche en surface (au soleil), plus bleue en profondeur.
    let base = mix(fbIceColour * 0.82, fbIceColour, clamp(sunlit, 0.0, 1.0));
    // Fissures sombres : sur une glace claire, c'est le contraste qui les rend visibles.
    let withBubbles = mix(base, vec3f(0.95, 0.98, 1.0), bubbles * 0.8);
    return mix(withBubbles, vec3f(0.30, 0.44, 0.60), cracks * 0.55);
}

// --------------------------------------------------------- houle (vertex) ---
// Glace = presque rigide : on garde un deplacement infime, uniquement en "allow".
#ifndef BLOXD_STRICT
fn bloxdLiquidVertex(vertex: BloxdVertexIn) -> BloxdVertex {
    var out = bloxdDefaultVertex(vertex);
    let topness = clamp(vertex.normal.y * 2.0, 0.0, 1.0);
    if (topness > 0.001) {
        let wp = bloxdWorldPosition(vertex.position);
        let t = bloxdSeconds();
        // Deux ondes tres lentes et de faible amplitude.
        let h = sin(wp.x * 0.35 + t * 0.35) * 0.012 + sin(wp.z * 0.42 - t * 0.28) * 0.010;
        out.position.y += h * topness;
    }
    return out;
}
#endif

// --------------------------------------------------------------- surface ---
fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(surface);
    let worldPos = bloxdWorldPosition(surface.position);
    let n = normalize(surface.normal);
    let sunlit = fbSunlitProbe(surface);

    out.colour = fbIceAlbedo(worldPos, sunlit);

    // La glace ne laisse presque rien passer : seule la surface fine s'eclaircit.
    let thickness = fbIceThicknessAt(surface.position);
    let depth01 = clamp(thickness / 5.0, 0.0, 1.0);
#ifdef BLOXD_ALPHA
    out.alpha = clamp(mix(fbIceOpacity - 0.10, fbIceOpacity, depth01), 0.0, 1.0);
#endif

    // Un peu de givre sur les bords surhaussés.
    let rim = smoothstep(0.55, 1.0, 1.0 - abs(n.y)) * 0.15;
    out.colour = mix(out.colour, vec3f(0.94, 0.97, 1.0), rim);
    out.emission += fbIceTint * 0.02;

    return out;
}

// ----------------------------------------------------------------- light ---
fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    if (!bloxdLit()) { return out; }

    let n = normalize(light.normal);
    let sunDir = fbSunDirection();
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let sunlit = fbSunlit(light);
    let dist = distance(bloxdEyePosition(), light.position);

    // Normale de glace : ondulation tres douce, pas de vraie houle.
    let topness = clamp(n.y * 2.0, 0.0, 1.0);
    let ripple = normalize(n + vec3f(
        sin(light.position.x * 1.7 + bloxdSeconds() * 0.4) * 0.03 * topness,
        0.0,
        cos(light.position.z * 1.9 - bloxdSeconds() * 0.35) * 0.03 * topness));

    // Fresnel fort : la glace devient miroir a angle rasant.
    let facing = clamp(dot(ripple, viewDir), 0.0, 1.0);
    let fresnel = 0.04 + 0.96 * pow(1.0 - facing, 5.0);

    var colour = bloxdLitColour(surface, light) * mix(1.0, 0.55, 1.0 - sunlit);

    // Reflet du ciel d'hiver.
    let skyReflect = mix(vec3f(0.72, 0.84, 1.0), fbFogColour, 0.4);
    colour = mix(colour, skyReflect, fresnel * 0.55);

    // Absorption : sous la glace, l'eau est sombre et bleue.
    let thickness = fbIceThicknessAt(light.position);
    let absorb = 1.0 - exp(-thickness * fbIceAbsorb);
    colour = mix(colour, vec3f(0.10, 0.24, 0.38), absorb * 0.55);

    // Eblouissement du soleil : tache large et diffuse sur la glace.
    let halfDir = normalize(viewDir + sunDir);
    let ndh = clamp(dot(ripple, halfDir), 0.0, 1.0);
    colour += vec3f(0.90, 0.96, 1.0) * (pow(ndh, 64.0) * fbIceSheen * 0.55 + pow(ndh, 8.0) * 0.10);

    // Torche sur la glace : reflet chaud dans le froid.
    let blockLight = clamp(max(light.blockLight.r, max(light.blockLight.g, light.blockLight.b)), 0.0, 1.0);
    if (blockLight > 0.001) {
        colour = mix(colour, colour * vec3f(1.20, 0.85, 0.55), 0.45 * blockLight);
    }

    // Brouillard + etalonnage + flocons, comme pour le terrain.
    let fog = clamp(1.0 - exp(-dist * fbFogDensity), 0.0, fbFogMax);
    let fogCol = mix(light.fogColour, fbFogColour, 0.75);
    colour = mix(colour, fogCol, max(fog, light.fogAlpha * 0.9));
    colour = fbGrade(colour, sunlit);

    let flakes = fbSnowfall(light, bloxdSeconds());
    if (flakes > 0.001) {
        colour = mix(colour, vec3f(0.98, 0.99, 1.0), flakes);
    }

    out.colour = clamp(colour, vec3f(0.0), vec3f(1.0));
    return out;
}
