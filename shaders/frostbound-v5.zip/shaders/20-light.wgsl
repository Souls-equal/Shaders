// ============================================================================
//  Frostbound - 20-light.wgsl : hooks "light" (couleur finale a l'ecran)
//  Particularite du theme : la neige eclaircit l'exterieur, les ombres sont
//  bleues et froides, et des flocons tombent en volume autour de la camera.
// ============================================================================

fn fbLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(surface, light);
    if (!bloxdLit()) { return out; }

    let t = bloxdSeconds();
    let n = normalize(light.normal);
    let sunDir = fbSunDirection();
    let viewDir = normalize(bloxdEyePosition() - light.position);
    let worldPos = bloxdWorldPosition(light.position);
    let dist = distance(bloxdEyePosition(), light.position);

    let sunlit = fbSunlit(light);
    let blockLight = clamp(max(light.blockLight.r, max(light.blockLight.g, light.blockLight.b)), 0.0, 1.0);

    // --- 1. Modele froid : soleil rasant sur les aretes --------------------
    let ndl = clamp(dot(n, sunDir), 0.0, 1.0);
    let shape = mix(1.0, 0.55 + 0.45 * ndl, fbSunSharp);
    var colour = bloxdLitColour(surface, light) * shape;

    // --- 2. Rebond de neige : le sol clair renvoie de la lumiere ----------
    //     Les faces tournees vers le bas et les faces verticales s'eclaircissent
    //     quand elles sont dehors : c'est ce qui donne l'aspect "blanc".
    let upward = clamp(n.y * 0.5 + 0.5, 0.0, 1.0);
    let bounce = fbSnowBounce * (1.0 - upward) * (0.35 + 0.65 * sunlit);
    colour += vec3f(fbSnowTint) * (colour * bounce * 0.75 + 0.014 * bounce);

    // --- 2b. Neige fraiche au soleil : les faces hautes renvoient presque
    //     toute la lumiere recue, ce qui detache les reliefs du sol plat.
    let topBoost = smoothstep(0.45, 1.0, n.y) * sunlit;
    colour += vec3f(fbSnowTint) * (topBoost * 0.065);

    // --- 3. Plancher lumineux froid (jamais de trou noir) -----------------
    colour += fbAmbientLift * (1.0 - blockLight) * (0.35 + 0.65 * light.skyLight);

    // --- 4. Ombres : bleu profond, presque pas d'assombrissement lineaire -
    //     On teinte plus qu'on n'eteint, pour garder l'image lisible.
    let openSky = sunlit;
    let shade = 1.0 - openSky;
    colour = mix(colour, colour * vec3f(0.42, 0.56, 0.92) + vec3f(0.008, 0.016, 0.038), shade * 0.9 * (1.0 - blockLight * 0.8));
    // Les faces a l'ombre restent lisibles : le ciel d'hiver diffuse partout.
    colour += vec3f(0.020, 0.030, 0.055) * shade * (1.0 - blockLight);

    // --- 5. Reflet de glace (sheen) sur les faces qui voient le soleil ----
    let halfDir = normalize(viewDir + sunDir);
    let ndh = clamp(dot(n, halfDir), 0.0, 1.0);
    let fresnel = pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 4.0);
    let sheen = pow(ndh, fbSheenPower) * fbSheenStrength * (0.35 + 0.65 * openSky);
    colour += vec3f(0.86, 0.94, 1.0) * (sheen + fresnel * 0.06 * openSky);

    // --- 6. Lumiere chaude (torche, lave) : la seule chaleur de l'image ---
    if (blockLight > 0.001) {
        let warm = vec3f(1.0, 0.62, 0.30);
        let halo = 1.0 - smoothstep(0.0, 1.0, blockLight);
        colour = mix(colour, colour * warm + vec3f(0.05, 0.022, 0.0) * blockLight, 0.55 * blockLight);
        // Contraste froid/chaud : autour d'une torche, la neige reste bleue.
        colour *= mix(vec3f(1.0), vec3f(0.90, 0.95, 1.05), halo * 0.4);
    }

    // --- 7. Brouillard de neige (remplace la brume du jeu) ----------------
    let fog = clamp(1.0 - exp(-dist * fbFogDensity), 0.0, fbFogMax);
    let fogCol = mix(light.fogColour, fbFogColour, 0.75);
    colour = mix(colour, fogCol, max(fog, light.fogAlpha * 0.9));

    // --- 8. Etalonnage froid ---------------------------------------------
    colour = fbGrade(colour, sunlit);

    // --- 9. Chute de neige devant la camera (par-dessus tout) -------------
    let flakes = fbSnowfall(light, t);
    if (flakes > 0.001) {
        // Un flocon est blanc mais prend la teinte de l'ambiance.
        let flakeCol = mix(vec3f(0.98, 0.99, 1.0), fogCol, clamp(dist / fbSnowfallRange, 0.0, 1.0) * 0.6);
        colour = mix(colour, flakeCol, flakes);
    }

    out.colour = clamp(colour, vec3f(0.0), vec3f(1.0));
    return out;
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return fbLight(surface, light);
}

fn bloxdModelLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    return fbLight(surface, light);
}
