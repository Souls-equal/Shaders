// ============================================================================
//  Frostbound - pack de shaders Bloxd.io (API v5, WebGPU)
//  01-config.wgsl : tous les reglages du theme "gele / noir & blanc"
//  Identifiants reserves : tout ce qui commence par "bloxd" appartient au
//  moteur. Les helpers de ce pack utilisent le prefixe "fb".
// ============================================================================

// --- Etalonnage "high key" (image claire, peu contrastee, presque monochrome)
const fbExposure: f32 = 1.10;
const fbHighKey: f32 = 0.70;        // 0 = pas d'eclaircissement des basses lumieres
const fbSaturation: f32 = 0.30;     // 0 = noir et blanc pur
const fbContrast: f32 = 1.04;       // < 1 = image douce, > 1 = dure

// --- Derive glacee
const fbIceTint: vec3f = vec3f(0.66, 0.80, 1.00);
const fbIceShift: f32 = 0.26;       // force du bleuissement
const fbShadowBlue: f32 = 0.55;     // bleuissement renforce dans les ombres

// --- Neige
const fbSnowTint: vec3f = vec3f(1.16, 1.22, 1.32);
const fbSnowAmount: f32 = 1.00;     // quantite de neige sur les surfaces hautes
const fbSnowMinUp: f32 = 0.35;      // a partir de quelle inclinaison la neige tient (n.y)
const fbSnowSoftness: f32 = 0.25;   // fondu du bord de la couverture
const fbSnowBounce: f32 = 0.28;     // lumiere renvoyee par la neige (ambiance)
const fbSnowGlitter: f32 = 0.35;     // intensite des etincelles de givre
const fbFrostDepth: f32 = 0.45;     // givre procedural sur les faces exposees

// --- Lumiere
const fbSunSharp: f32 = 0.6;        // 0 = eclairage plat, 1 = soleil tres modelant
const fbSheenPower: f32 = 46.0;     // nettete du reflet de glace sur les blocs
const fbSheenStrength: f32 = 0.30;
const fbAmbientLift: vec3f = vec3f(0.055, 0.072, 0.100); // plancher lumineux froid

// --- Atmosphere : brouillard de neige, tres dense et proche
const fbFogColour: vec3f = vec3f(0.82, 0.88, 0.96);
const fbFogDensity: f32 = 0.009;    // 0 = pas de brouillard ajoute
const fbFogMax: f32 = 0.80;

// --- Glace (programme liquid : l'eau est gelee)
const fbIceColour: vec3f = vec3f(0.70, 0.84, 0.98);
const fbIceOpacity: f32 = 0.94;     // opacite de la glace pres de la surface
const fbIceAbsorb: f32 = 0.10;      // absorption par bloc d'epaisseur
const fbIceSheen: f32 = 1.10;       // eblouissement du soleil sur la glace

// --- Vegetation (hooks vertex, jeux "allow" uniquement)
const fbSwayAmount: f32 = 0.022;    // neige lourde : tres peu de mouvement
const fbSwaySpeed: f32 = 0.9;

// --- Chute de neige volumetrique (hook light, proche de la camera)
const fbSnowfallAmount: f32 = 0.75; // 0 = pas de flocons
const fbSnowfallRange: f32 = 26.0;  // distance au-dela de laquelle on ne dessine plus
