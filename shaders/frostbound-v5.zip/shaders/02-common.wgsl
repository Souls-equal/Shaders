// ============================================================================
//  Frostbound - 02-common.wgsl : briques partagees
// ============================================================================

fn fbLuma(c: vec3f) -> f32 {
    return dot(c, vec3f(0.2126, 0.7152, 0.0722));
}

fn fbSaturate(c: vec3f, amount: f32) -> vec3f {
    let l = fbLuma(c);
    return clamp(mix(vec3f(l), c, amount), vec3f(0.0), vec3f(1.0));
}

// Courbe de levage du skyLight du moteur, inversee : sans cela les ombres
// restent invisibles (sous un arbre, skyLight vaut deja 0.97).
fn fbUnlift(y: f32) -> f32 {
    let c = pow(clamp(1.0 - y, 0.0, 1.0), 1.0 / 3.0);
    return clamp(3.0 * (1.0 - c) / max(3.0 - 2.0 * c, 1e-4), 0.0, 1.0);
}

// Direction du soleil survit ici a un ciel sans soleil : on garde un vecteur
// utilisable pour le modelé des faces.
fn fbSunDirection() -> vec3f {
    let d = bloxdSunDirection();
    if (dot(d, d) < 1e-6) { return vec3f(0.12, 0.86, 0.5); }
    return normalize(d);
}

// "Vue du ciel" binarisee : la seule source d'ombre disponible.
fn fbSunlit(light: BloxdLightIn) -> f32 {
    let raw = fbUnlift(clamp(light.skyLight, 0.0, 1.0));
    return smoothstep(0.72, 0.86, raw);
}

// Hauteur 0..1 dans le bloc courant (pour le givre et la neige procedurale).
fn fbLocalHeight(position: vec3f, normal: vec3f) -> f32 {
    let inside = position - normal * 0.5;   // on recule d'un demi-bloc dans le bloc
    return fract(inside.y);
}

// Bruit "value" 2D lisse, sans texture : 4 coins haches + interpolation.
fn fbHash13(p: vec3f) -> f32 {
    return fract(sin(dot(p, vec3f(127.1, 311.7, 74.7))) * 43758.5453);
}

fn fbHash12(p: vec2f) -> f32 {
    return fract(sin(dot(p, vec2f(127.1, 311.7))) * 43758.5453);
}

fn fbNoise(p: vec2f) -> f32 {
    let i = floor(p);
    let f = fract(p);
    let u = f * f * (3.0 - 2.0 * f);
    let a = fbHash12(i);
    let b = fbHash12(i + vec2f(1.0, 0.0));
    let c = fbHash12(i + vec2f(0.0, 1.0));
    let d = fbHash12(i + vec2f(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Givre procedural : motif cristallin sur les faces qui voient le ciel.
// Retourne 0 (rien) a 1 (givre epais).
fn fbFrost(worldPos: vec3f, normal: vec3f, sunlit: f32) -> f32 {
    // On projette la position sur les deux axes tangents a la face, pour que
    // le motif "colle" au bloc quelle que soit l'orientation.
    let tangent = normalize(cross(normal, vec3f(0.0, 1.0, 0.001)));
    let bitangent = cross(normal, tangent);
    let u = dot(worldPos, tangent) * 4.0;
    let v = dot(worldPos, bitangent) * 4.0;
    let n = fbNoise(vec2f(u, v)) * 0.6 + fbNoise(vec2f(u * 2.7, v * 2.7)) * 0.4;
    let veins = smoothstep(0.55, 0.85, n);
    // Le givre se concentre la ou le ciel est visible (faces hautes, non abritees).
    return clamp(veins * (0.55 + 0.45 * sunlit) * fbFrostDepth, 0.0, 1.0);
}

// Etincelle de givre : cellules deterministes qui scintillent brievement.
fn fbGlitter(worldPos: vec3f, t: f32) -> f32 {
    let cell = floor(worldPos * 4.5);
    let rnd = fbHash12(cell.xz + cell.y * 17.0);
    let phase = fract(t * 0.5 + rnd);
    let blink = pow(max(0.0, sin(phase * 6.2831853)), 44.0);
    return blink * step(0.55, rnd);
}

// Flocon de neige volumetrique : deux couches de cellules animees autour de la
// camera. Renvoie l'opacite a appliquer sur la couleur du pixel.
fn fbSnowfall(light: BloxdLightIn, t: f32) -> f32 {
    let eye = bloxdEyePosition();
    let rel = light.position - eye;
    let dist = length(rel);
    if (dist > fbSnowfallRange) { return 0.0; }

    // Deux couches a des echelles differentes : gros flocons proches, fins au loin.
    var flakes = 0.0;
    for (var layer = 0; layer < 2; layer++) {
        let lf = f32(layer);
        let scale = 1.4 + lf * 1.9;
        let speed = 0.9 + lf * 0.7;
        // Le flocon tombe et derive : on decale la position monde en fonction du temps.
        let p = bloxdWorldPosition(light.position)
              + vec3f(sin(t * 0.6 + lf * 2.1) * 1.2, -t * speed, cos(t * 0.45 + lf) * 1.2);
        let cell = floor(p * scale);
        let rnd = fbHash13(cell + vec3f(lf * 7.3));
        // Seuls ~30 % des cellules contiennent un flocon.
        if (rnd > 0.30) { continue; }
        // Position du flocon dans sa cellule : decalee par un tirage par cellule,
        // sinon les flocons dessinent une grille.
        let jitter = vec3f(
            fbHash13(cell + vec3f(11.0, 3.0, 5.0)),
            fbHash13(cell + vec3f(2.0, 17.0, 9.0)),
            fbHash13(cell + vec3f(23.0, 7.0, 13.0))) - vec3f(0.5);
        let local = fract(p * scale) - vec3f(0.5) - jitter * 0.55;
        let size = 0.20 - lf * 0.06;
        let d = length(local);
        let core = 1.0 - smoothstep(size * 0.30, size, d);
        flakes += core * (1.0 - lf * 0.5);
    }

    // Fondu avec la distance : les flocons lointains se fondent dans la brume.
    let nearFade = smoothstep(fbSnowfallRange, fbSnowfallRange * 0.45, dist);
    let closeFade = smoothstep(0.4, 1.8, dist);   // evite d'aveugler la camera
    return clamp(flakes * fbSnowfallAmount * nearFade * closeFade, 0.0, 0.9);
}

// Epaisseur de glace/eau (blocs) via la texture de profondeur de scene.
// Disponible uniquement dans les variantes "liquid" (BLOXD_SCENE_DEPTH).
fn fbIceThicknessAt(position: vec3f) -> f32 {
#ifdef BLOXD_SCENE_DEPTH
    let behind = bloxdOpaqueBehind();
    if (behind.hit) {
        return clamp(behind.distance - distance(bloxdEyePosition(), position), 0.0, 10.0);
    }
    return 10.0;
#else
    return 3.0;
#endif
}

// Etalonnage commun : expose, desature, bleuit, eclaire les basses lumieres,
// puis remonte les noirs vers un bleu tres sombre (jamais de noir absolu).
fn fbGrade(colour: vec3f, sunlit: f32) -> vec3f {
    var c = max(colour, vec3f(0.0)) * fbExposure;

    // 1. Desaturation : on garde une trace de couleur, mais tres peu.
    c = fbSaturate(c, fbSaturation);

    // 2. Derive glacee, plus forte dans les zones d'ombre.
    let shift = fbIceShift * mix(1.0, 1.5, 1.0 - sunlit);
    c = mix(c, c * fbIceTint, clamp(shift, 0.0, 1.0));

    // 3. High key : on souleve les basses lumieres pour une image "neige".
    c = mix(c, sqrt(clamp(c, vec3f(0.0), vec3f(1.0))), fbHighKey * 0.35);
    c = c + vec3f(fbHighKey * 0.030);

    // 4. Contraste doux autour du gris.
    let sc = clamp(c, vec3f(0.0), vec3f(1.0));
    c = clamp((sc - vec3f(0.5)) * fbContrast + vec3f(0.5), vec3f(0.0), vec3f(1.0));

    // 5. Noirs "glaces" : jamais 0,0,0 mais un bleu nuit.
    c = mix(c, max(c, vec3f(0.030, 0.040, 0.058)), 0.6);

    return clamp(c, vec3f(0.0), vec3f(1.0));
}
