// ============================================================================
//  Frostbound - 10-surface.wgsl : hooks "surface" (matiere)
//  Ici on ne touche qu'a l'albedo et a l'emission.
// ============================================================================

// Surface commune. "snowPass" : true pour le terrain (il neige partout),
// false pour les modeles (joueurs, mobs, objets : ils ne sont pas recouverts).
fn fbSurface(s: BloxdSurfaceIn, snowPass: bool, glitter: f32) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    let worldPos = bloxdWorldPosition(s.position);
    let n = normalize(s.normal);
    let t = bloxdSeconds();
    let sunlit = fbSunlitProbe(s);

    // --- 1. Neige sur les surfaces horizontales ---------------------------
    if (snowPass) {
        let up = smoothstep(fbSnowMinUp, fbSnowMinUp + fbSnowSoftness, n.y);
        if (up > 0.001) {
            // Accumulation legerement bruitee pour casser l'aspect "peint".
            let snowPatch = fbNoise(worldPos.xz * 0.55) * 0.18 + 0.82;
            let cover = clamp(up * snowPatch * fbSnowAmount, 0.0, 1.0);
            // La neige est une matiere claire : on MELANGE l'albedo vers le
            // blanc bleute au lieu de le multiplier (sinon le gazon devient gris).
            out.colour = mix(out.colour, vec3f(fbSnowTint) * (0.97 + 0.03 * snowPatch), cover);
        }
    }

    // --- 2. Givre : voiles cristallins sur les faces exposees -------------
    let frost = fbFrost(worldPos, n, sunlit);
    if (frost > 0.001) {
        let ice = vec3f(0.80, 0.90, 1.0);
        out.colour = mix(out.colour, ice, frost * 0.70);
        // Un peu d'emission : la glace renvoie de la lumiere dans l'ombre.
        out.emission += fbIceTint * (frost * 0.05);
    }

    // --- 2b. Vegetation : feuillage assombri puis saupoudre de neige ------
    if (snowPass && s.flags.vegetation) {
        // Sans cet assombrissement, la desaturation globale transforme les
        // feuilles en un mur gris clair : on garde un vert-noir de conifere.
        out.colour *= vec3f(0.30, 0.42, 0.36);
        let dust = fbNoise(worldPos.xz * 1.4 + worldPos.y * 0.7) * 0.4 + 0.6;
        out.colour = mix(out.colour, vec3f(0.86, 0.92, 0.99), 0.30 * dust);
    }

    // --- 2bb. Troncs et bois : gris-bleu de bois mort --------------------
    if (snowPass && !s.flags.vegetation && !s.flags.rock && !s.flags.dirt && !s.flags.sand && !s.flags.emissive && !s.flags.flat) {
        out.colour = mix(out.colour, out.colour * vec3f(0.62, 0.66, 0.72), 0.5);
    }

    // --- 2c. Entites : on pre-compense la desaturation globale ------------
    //     Les joueurs/mobs gardent des couleurs lisibles au milieu du blanc.
    if (!snowPass) {
        out.colour = mix(vec3f(fbLuma(out.colour)), out.colour, 1.7);
    }

    // --- 3. Etincelles de givre (rares, sinon la neige "bruit") -----------
    if (glitter > 0.0 && !s.flags.vegetation) {
        let spark = fbGlitter(worldPos, t);
        out.emission += vec3f(0.92, 0.97, 1.0) * (spark * glitter * fbSnowGlitter * 0.12);
    }

    // --- 3b. Roche : on l'assombrit et on la desature, sinon elle flotte ---
    if (s.flags.rock && n.y < 0.35) {
        out.colour = mix(out.colour, out.colour * vec3f(0.78, 0.84, 0.92), 0.45);
    }

    // --- 4. Blocs lumineux : lueur froide, stable (pas de pulsation) ------
    if (s.flags.emissive) {
        let lum = fbLuma(out.colour);
        out.emission += mix(out.colour, vec3f(0.62, 0.80, 1.0), 0.45) * lum * 0.55;
    }

    return out;
}

// Le hook surface ne recoit pas les valeurs de lumiere (blockLight/skyLight) :
// on approxime "voit le ciel" avec l'orientation de la face. Les vraies ombres
// de neige/givre sont appliquees dans le hook light, qui a l'information.
fn fbSunlitProbe(s: BloxdSurfaceIn) -> f32 {
    return smoothstep(0.1, 0.9, normalize(s.normal).y);
}

// ----------------------------------------------------------------- terrain --
fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return fbSurface(surface, true, 1.0);
}

// ------------------------------------------------------------------- model --
fn bloxdModelSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    return fbSurface(surface, false, 0.15);
}
